namespace ASR550example_CS
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.Label1 = new System.Windows.Forms.Label();
      this.CheckBoxDataBlockPresent = new System.Windows.Forms.CheckBox();
      this.LabelCountryCode = new System.Windows.Forms.Label();
      this.ComboBoxPorts = new System.Windows.Forms.ComboBox();
      this.LabelRetaggingCounter = new System.Windows.Forms.Label();
      this.Label3 = new System.Windows.Forms.Label();
      this.GroupBoxIsoNumbers = new System.Windows.Forms.GroupBox();
      this.Label7 = new System.Windows.Forms.Label();
      this.LabelID = new System.Windows.Forms.Label();
      this.LabelReservedZone = new System.Windows.Forms.Label();
      this.Label4 = new System.Windows.Forms.Label();
      this.Label6 = new System.Windows.Forms.Label();
      this.LabelTagType = new System.Windows.Forms.Label();
      this.LabelUserInformation = new System.Windows.Forms.Label();
      this.CheckBoxAnimalTag = new System.Windows.Forms.CheckBox();
      this.Label5 = new System.Windows.Forms.Label();
      this.ButtonGet_AntennaStatus = new System.Windows.Forms.Button();
      this.GroupBoxTagnumber = new System.Windows.Forms.GroupBox();
      this.LabelTagnumber = new System.Windows.Forms.Label();
      this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
      this.ToolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
      this.GroupBoxDedicatedCommands = new System.Windows.Forms.GroupBox();
      this.ButtonGetReaderVersion = new System.Windows.Forms.Button();
      this.ButtonStart_FastAutotuning = new System.Windows.Forms.Button();
      this.ButtonGetReaderSerialNumber = new System.Windows.Forms.Button();
      this.ButtonDevice_Check = new System.Windows.Forms.Button();
      this.GroupBoxGenericCommands = new System.Windows.Forms.GroupBox();
      this.ButtonExecuteCommand1 = new System.Windows.Forms.Button();
      this.ButtonGetData = new System.Windows.Forms.Button();
      this.ButtonExecuteCommand2 = new System.Windows.Forms.Button();
      this.ComboBoxCfgDelayTime = new System.Windows.Forms.ComboBox();
      this.GroupBoxCfgDelayTime = new System.Windows.Forms.GroupBox();
      this.ButtonGetDelaytime = new System.Windows.Forms.Button();
      this.ButtonSetDelaytime = new System.Windows.Forms.Button();
      this.ButtonReset_All = new System.Windows.Forms.Button();
      this.ButtonGetOutputFormat = new System.Windows.Forms.Button();
      this.LabelBaudrate = new System.Windows.Forms.Label();
      this.ButtonConnect = new System.Windows.Forms.Button();
      this.ComboBoxBaudrate = new System.Windows.Forms.ComboBox();
      this.TimerColorNumber = new System.Windows.Forms.Timer(this.components);
      this.LabelComport = new System.Windows.Forms.Label();
      this.GroupBoxCommands = new System.Windows.Forms.GroupBox();
      this.GroupBoxConfiguration = new System.Windows.Forms.GroupBox();
      this.GroupBoxCfgOutputFormat = new System.Windows.Forms.GroupBox();
      this.ButtonSetOutputFormat = new System.Windows.Forms.Button();
      this.ComboBoxCfgOutputFormat = new System.Windows.Forms.ComboBox();
      this.GroupBoxCfgSerialBaudrate = new System.Windows.Forms.GroupBox();
      this.ButtonSetSerialBaudrate = new System.Windows.Forms.Button();
      this.ComboBoxCfgSerialBaudrate = new System.Windows.Forms.ComboBox();
      this.ButtonGetSerialBaudrate = new System.Windows.Forms.Button();
      this.GroupBoxConnection = new System.Windows.Forms.GroupBox();
      this.GroupBoxIsoNumbers.SuspendLayout();
      this.GroupBoxTagnumber.SuspendLayout();
      this.StatusStrip1.SuspendLayout();
      this.GroupBoxDedicatedCommands.SuspendLayout();
      this.GroupBoxGenericCommands.SuspendLayout();
      this.GroupBoxCfgDelayTime.SuspendLayout();
      this.GroupBoxCommands.SuspendLayout();
      this.GroupBoxConfiguration.SuspendLayout();
      this.GroupBoxCfgOutputFormat.SuspendLayout();
      this.GroupBoxCfgSerialBaudrate.SuspendLayout();
      this.GroupBoxConnection.SuspendLayout();
      this.SuspendLayout();
      // 
      // Label1
      // 
      this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.Label1.Location = new System.Drawing.Point(6, 16);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(74, 15);
      this.Label1.TabIndex = 5;
      this.Label1.Text = "Country Code";
      // 
      // CheckBoxDataBlockPresent
      // 
      this.CheckBoxDataBlockPresent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
      this.CheckBoxDataBlockPresent.Location = new System.Drawing.Point(383, 36);
      this.CheckBoxDataBlockPresent.Name = "CheckBoxDataBlockPresent";
      this.CheckBoxDataBlockPresent.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
      this.CheckBoxDataBlockPresent.Size = new System.Drawing.Size(77, 17);
      this.CheckBoxDataBlockPresent.TabIndex = 18;
      this.CheckBoxDataBlockPresent.Text = "Data Block";
      this.CheckBoxDataBlockPresent.UseVisualStyleBackColor = true;
      // 
      // LabelCountryCode
      // 
      this.LabelCountryCode.BackColor = System.Drawing.SystemColors.Window;
      this.LabelCountryCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.LabelCountryCode.Location = new System.Drawing.Point(80, 16);
      this.LabelCountryCode.Name = "LabelCountryCode";
      this.LabelCountryCode.Size = new System.Drawing.Size(36, 15);
      this.LabelCountryCode.TabIndex = 6;
      // 
      // ComboBoxPorts
      // 
      this.ComboBoxPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.ComboBoxPorts.FormattingEnabled = true;
      this.ComboBoxPorts.Location = new System.Drawing.Point(69, 19);
      this.ComboBoxPorts.Name = "ComboBoxPorts";
      this.ComboBoxPorts.Size = new System.Drawing.Size(75, 21);
      this.ComboBoxPorts.TabIndex = 1;
      // 
      // LabelRetaggingCounter
      // 
      this.LabelRetaggingCounter.BackColor = System.Drawing.SystemColors.Window;
      this.LabelRetaggingCounter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.LabelRetaggingCounter.Location = new System.Drawing.Point(340, 36);
      this.LabelRetaggingCounter.Name = "LabelRetaggingCounter";
      this.LabelRetaggingCounter.Size = new System.Drawing.Size(36, 15);
      this.LabelRetaggingCounter.TabIndex = 17;
      // 
      // Label3
      // 
      this.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.Label3.Location = new System.Drawing.Point(122, 16);
      this.Label3.Name = "Label3";
      this.Label3.Size = new System.Drawing.Size(24, 15);
      this.Label3.TabIndex = 7;
      this.Label3.Text = "ID";
      // 
      // GroupBoxIsoNumbers
      // 
      this.GroupBoxIsoNumbers.BackColor = System.Drawing.SystemColors.Control;
      this.GroupBoxIsoNumbers.Controls.Add(this.Label1);
      this.GroupBoxIsoNumbers.Controls.Add(this.CheckBoxDataBlockPresent);
      this.GroupBoxIsoNumbers.Controls.Add(this.LabelCountryCode);
      this.GroupBoxIsoNumbers.Controls.Add(this.LabelRetaggingCounter);
      this.GroupBoxIsoNumbers.Controls.Add(this.Label3);
      this.GroupBoxIsoNumbers.Controls.Add(this.Label7);
      this.GroupBoxIsoNumbers.Controls.Add(this.LabelID);
      this.GroupBoxIsoNumbers.Controls.Add(this.LabelReservedZone);
      this.GroupBoxIsoNumbers.Controls.Add(this.Label4);
      this.GroupBoxIsoNumbers.Controls.Add(this.Label6);
      this.GroupBoxIsoNumbers.Controls.Add(this.LabelTagType);
      this.GroupBoxIsoNumbers.Controls.Add(this.LabelUserInformation);
      this.GroupBoxIsoNumbers.Controls.Add(this.CheckBoxAnimalTag);
      this.GroupBoxIsoNumbers.Controls.Add(this.Label5);
      this.GroupBoxIsoNumbers.Location = new System.Drawing.Point(7, 48);
      this.GroupBoxIsoNumbers.Name = "GroupBoxIsoNumbers";
      this.GroupBoxIsoNumbers.Size = new System.Drawing.Size(468, 56);
      this.GroupBoxIsoNumbers.TabIndex = 19;
      this.GroupBoxIsoNumbers.TabStop = false;
      this.GroupBoxIsoNumbers.Text = "ISO numbers";
      this.GroupBoxIsoNumbers.Visible = false;
      // 
      // Label7
      // 
      this.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.Label7.Location = new System.Drawing.Point(238, 36);
      this.Label7.Name = "Label7";
      this.Label7.Size = new System.Drawing.Size(101, 15);
      this.Label7.TabIndex = 16;
      this.Label7.Text = "Retagging Counter";
      // 
      // LabelID
      // 
      this.LabelID.BackColor = System.Drawing.SystemColors.Window;
      this.LabelID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.LabelID.Location = new System.Drawing.Point(146, 16);
      this.LabelID.Name = "LabelID";
      this.LabelID.Size = new System.Drawing.Size(86, 15);
      this.LabelID.TabIndex = 8;
      // 
      // LabelReservedZone
      // 
      this.LabelReservedZone.BackColor = System.Drawing.SystemColors.Window;
      this.LabelReservedZone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.LabelReservedZone.Location = new System.Drawing.Point(210, 36);
      this.LabelReservedZone.Name = "LabelReservedZone";
      this.LabelReservedZone.Size = new System.Drawing.Size(22, 15);
      this.LabelReservedZone.TabIndex = 15;
      // 
      // Label4
      // 
      this.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.Label4.Location = new System.Drawing.Point(238, 16);
      this.Label4.Name = "Label4";
      this.Label4.Size = new System.Drawing.Size(46, 15);
      this.Label4.TabIndex = 9;
      this.Label4.Text = "Type";
      // 
      // Label6
      // 
      this.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.Label6.Location = new System.Drawing.Point(123, 36);
      this.Label6.Name = "Label6";
      this.Label6.Size = new System.Drawing.Size(87, 15);
      this.Label6.TabIndex = 14;
      this.Label6.Text = "Reserved Zone";
      // 
      // LabelTagType
      // 
      this.LabelTagType.BackColor = System.Drawing.SystemColors.Window;
      this.LabelTagType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.LabelTagType.Location = new System.Drawing.Point(285, 16);
      this.LabelTagType.Name = "LabelTagType";
      this.LabelTagType.Size = new System.Drawing.Size(91, 15);
      this.LabelTagType.TabIndex = 10;
      // 
      // LabelUserInformation
      // 
      this.LabelUserInformation.BackColor = System.Drawing.SystemColors.Window;
      this.LabelUserInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.LabelUserInformation.Location = new System.Drawing.Point(91, 36);
      this.LabelUserInformation.Name = "LabelUserInformation";
      this.LabelUserInformation.Size = new System.Drawing.Size(25, 15);
      this.LabelUserInformation.TabIndex = 13;
      // 
      // CheckBoxAnimalTag
      // 
      this.CheckBoxAnimalTag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
      this.CheckBoxAnimalTag.Location = new System.Drawing.Point(382, 16);
      this.CheckBoxAnimalTag.Name = "CheckBoxAnimalTag";
      this.CheckBoxAnimalTag.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
      this.CheckBoxAnimalTag.Size = new System.Drawing.Size(78, 17);
      this.CheckBoxAnimalTag.TabIndex = 11;
      this.CheckBoxAnimalTag.Text = "Animal Tag";
      this.CheckBoxAnimalTag.UseVisualStyleBackColor = true;
      // 
      // Label5
      // 
      this.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.Label5.Location = new System.Drawing.Point(6, 36);
      this.Label5.Name = "Label5";
      this.Label5.Size = new System.Drawing.Size(87, 15);
      this.Label5.TabIndex = 12;
      this.Label5.Text = "User Information";
      // 
      // ButtonGet_AntennaStatus
      // 
      this.ButtonGet_AntennaStatus.Location = new System.Drawing.Point(152, 55);
      this.ButtonGet_AntennaStatus.Name = "ButtonGet_AntennaStatus";
      this.ButtonGet_AntennaStatus.Size = new System.Drawing.Size(140, 30);
      this.ButtonGet_AntennaStatus.TabIndex = 11;
      this.ButtonGet_AntennaStatus.Text = "Get_AntennaStatus";
      this.ButtonGet_AntennaStatus.UseVisualStyleBackColor = true;
      this.ButtonGet_AntennaStatus.Click += new System.EventHandler(this.ButtonGet_AntennaStatus_Click);
      // 
      // GroupBoxTagnumber
      // 
      this.GroupBoxTagnumber.Controls.Add(this.GroupBoxIsoNumbers);
      this.GroupBoxTagnumber.Controls.Add(this.LabelTagnumber);
      this.GroupBoxTagnumber.Location = new System.Drawing.Point(12, 6);
      this.GroupBoxTagnumber.Name = "GroupBoxTagnumber";
      this.GroupBoxTagnumber.Size = new System.Drawing.Size(480, 129);
      this.GroupBoxTagnumber.TabIndex = 19;
      this.GroupBoxTagnumber.TabStop = false;
      this.GroupBoxTagnumber.Text = "Tagnumber";
      // 
      // LabelTagnumber
      // 
      this.LabelTagnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.LabelTagnumber.Location = new System.Drawing.Point(11, 16);
      this.LabelTagnumber.Name = "LabelTagnumber";
      this.LabelTagnumber.Size = new System.Drawing.Size(463, 21);
      this.LabelTagnumber.TabIndex = 4;
      this.LabelTagnumber.Text = "Tagnumber goes here...";
      // 
      // StatusStrip1
      // 
      this.StatusStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.StatusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripStatusLabel1});
      this.StatusStrip1.Location = new System.Drawing.Point(0, 467);
      this.StatusStrip1.Name = "StatusStrip1";
      this.StatusStrip1.Size = new System.Drawing.Size(655, 22);
      this.StatusStrip1.TabIndex = 22;
      this.StatusStrip1.Text = "StatusStrip1";
      // 
      // ToolStripStatusLabel1
      // 
      this.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1";
      this.ToolStripStatusLabel1.Size = new System.Drawing.Size(640, 17);
      this.ToolStripStatusLabel1.Spring = true;
      this.ToolStripStatusLabel1.Text = "status info goes here...";
      // 
      // GroupBoxDedicatedCommands
      // 
      this.GroupBoxDedicatedCommands.Controls.Add(this.ButtonGetReaderVersion);
      this.GroupBoxDedicatedCommands.Controls.Add(this.ButtonStart_FastAutotuning);
      this.GroupBoxDedicatedCommands.Controls.Add(this.ButtonGetReaderSerialNumber);
      this.GroupBoxDedicatedCommands.Controls.Add(this.ButtonDevice_Check);
      this.GroupBoxDedicatedCommands.Controls.Add(this.ButtonGet_AntennaStatus);
      this.GroupBoxDedicatedCommands.Location = new System.Drawing.Point(7, 11);
      this.GroupBoxDedicatedCommands.Name = "GroupBoxDedicatedCommands";
      this.GroupBoxDedicatedCommands.Size = new System.Drawing.Size(473, 93);
      this.GroupBoxDedicatedCommands.TabIndex = 24;
      this.GroupBoxDedicatedCommands.TabStop = false;
      this.GroupBoxDedicatedCommands.Text = "Dedicated commands";
      // 
      // ButtonGetReaderVersion
      // 
      this.ButtonGetReaderVersion.Location = new System.Drawing.Point(6, 19);
      this.ButtonGetReaderVersion.Name = "ButtonGetReaderVersion";
      this.ButtonGetReaderVersion.Size = new System.Drawing.Size(140, 30);
      this.ButtonGetReaderVersion.TabIndex = 3;
      this.ButtonGetReaderVersion.Text = "Get firmware version";
      this.ButtonGetReaderVersion.UseVisualStyleBackColor = true;
      this.ButtonGetReaderVersion.Click += new System.EventHandler(this.ButtonGetReaderVersion_Click);
      // 
      // ButtonStart_FastAutotuning
      // 
      this.ButtonStart_FastAutotuning.Location = new System.Drawing.Point(298, 19);
      this.ButtonStart_FastAutotuning.Name = "ButtonStart_FastAutotuning";
      this.ButtonStart_FastAutotuning.Size = new System.Drawing.Size(140, 30);
      this.ButtonStart_FastAutotuning.TabIndex = 9;
      this.ButtonStart_FastAutotuning.Text = "Auto tuning";
      this.ButtonStart_FastAutotuning.UseVisualStyleBackColor = true;
      this.ButtonStart_FastAutotuning.Click += new System.EventHandler(this.ButtonStart_FastAutotuning_Click);
      // 
      // ButtonGetReaderSerialNumber
      // 
      this.ButtonGetReaderSerialNumber.Location = new System.Drawing.Point(152, 19);
      this.ButtonGetReaderSerialNumber.Name = "ButtonGetReaderSerialNumber";
      this.ButtonGetReaderSerialNumber.Size = new System.Drawing.Size(140, 30);
      this.ButtonGetReaderSerialNumber.TabIndex = 7;
      this.ButtonGetReaderSerialNumber.Text = "Get reader serial No";
      this.ButtonGetReaderSerialNumber.UseVisualStyleBackColor = true;
      this.ButtonGetReaderSerialNumber.Click += new System.EventHandler(this.ButtonGetReaderSerialNumber_Click);
      // 
      // ButtonDevice_Check
      // 
      this.ButtonDevice_Check.Location = new System.Drawing.Point(6, 55);
      this.ButtonDevice_Check.Name = "ButtonDevice_Check";
      this.ButtonDevice_Check.Size = new System.Drawing.Size(140, 30);
      this.ButtonDevice_Check.TabIndex = 10;
      this.ButtonDevice_Check.Text = "Device_Check";
      this.ButtonDevice_Check.UseVisualStyleBackColor = true;
      this.ButtonDevice_Check.Click += new System.EventHandler(this.ButtonDevice_Check_Click);
      // 
      // GroupBoxGenericCommands
      // 
      this.GroupBoxGenericCommands.Controls.Add(this.ButtonExecuteCommand1);
      this.GroupBoxGenericCommands.Controls.Add(this.ButtonGetData);
      this.GroupBoxGenericCommands.Controls.Add(this.ButtonExecuteCommand2);
      this.GroupBoxGenericCommands.Location = new System.Drawing.Point(486, 11);
      this.GroupBoxGenericCommands.Name = "GroupBoxGenericCommands";
      this.GroupBoxGenericCommands.Size = new System.Drawing.Size(143, 155);
      this.GroupBoxGenericCommands.TabIndex = 23;
      this.GroupBoxGenericCommands.TabStop = false;
      this.GroupBoxGenericCommands.Text = "Generic commands";
      // 
      // ButtonExecuteCommand1
      // 
      this.ButtonExecuteCommand1.Location = new System.Drawing.Point(9, 19);
      this.ButtonExecuteCommand1.Name = "ButtonExecuteCommand1";
      this.ButtonExecuteCommand1.Size = new System.Drawing.Size(127, 30);
      this.ButtonExecuteCommand1.TabIndex = 21;
      this.ButtonExecuteCommand1.Text = "RF field ON";
      this.ButtonExecuteCommand1.UseVisualStyleBackColor = true;
      this.ButtonExecuteCommand1.Click += new System.EventHandler(this.ButtonExecuteCommand1_Click);
      // 
      // ButtonGetData
      // 
      this.ButtonGetData.Location = new System.Drawing.Point(9, 91);
      this.ButtonGetData.Name = "ButtonGetData";
      this.ButtonGetData.Size = new System.Drawing.Size(127, 30);
      this.ButtonGetData.TabIndex = 22;
      this.ButtonGetData.Text = "RF activation request";
      this.ButtonGetData.UseVisualStyleBackColor = true;
      this.ButtonGetData.Click += new System.EventHandler(this.ButtonGetData_Click);
      // 
      // ButtonExecuteCommand2
      // 
      this.ButtonExecuteCommand2.Location = new System.Drawing.Point(9, 55);
      this.ButtonExecuteCommand2.Name = "ButtonExecuteCommand2";
      this.ButtonExecuteCommand2.Size = new System.Drawing.Size(127, 30);
      this.ButtonExecuteCommand2.TabIndex = 20;
      this.ButtonExecuteCommand2.Text = "RF field OFF";
      this.ButtonExecuteCommand2.UseVisualStyleBackColor = true;
      this.ButtonExecuteCommand2.Click += new System.EventHandler(this.ButtonExecuteCommand2_Click);
      // 
      // ComboBoxCfgDelayTime
      // 
      this.ComboBoxCfgDelayTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.ComboBoxCfgDelayTime.FormattingEnabled = true;
      this.ComboBoxCfgDelayTime.Location = new System.Drawing.Point(7, 17);
      this.ComboBoxCfgDelayTime.Name = "ComboBoxCfgDelayTime";
      this.ComboBoxCfgDelayTime.Size = new System.Drawing.Size(99, 21);
      this.ComboBoxCfgDelayTime.TabIndex = 13;
      // 
      // GroupBoxCfgDelayTime
      // 
      this.GroupBoxCfgDelayTime.Controls.Add(this.ComboBoxCfgDelayTime);
      this.GroupBoxCfgDelayTime.Controls.Add(this.ButtonGetDelaytime);
      this.GroupBoxCfgDelayTime.Controls.Add(this.ButtonSetDelaytime);
      this.GroupBoxCfgDelayTime.Location = new System.Drawing.Point(6, 72);
      this.GroupBoxCfgDelayTime.Name = "GroupBoxCfgDelayTime";
      this.GroupBoxCfgDelayTime.Size = new System.Drawing.Size(282, 43);
      this.GroupBoxCfgDelayTime.TabIndex = 12;
      this.GroupBoxCfgDelayTime.TabStop = false;
      this.GroupBoxCfgDelayTime.Text = "DelayTime";
      // 
      // ButtonGetDelaytime
      // 
      this.ButtonGetDelaytime.Location = new System.Drawing.Point(148, 17);
      this.ButtonGetDelaytime.Name = "ButtonGetDelaytime";
      this.ButtonGetDelaytime.Size = new System.Drawing.Size(50, 21);
      this.ButtonGetDelaytime.TabIndex = 14;
      this.ButtonGetDelaytime.Text = "Get";
      this.ButtonGetDelaytime.UseVisualStyleBackColor = true;
      this.ButtonGetDelaytime.Click += new System.EventHandler(this.ButtonGetDelaytime_Click);
      // 
      // ButtonSetDelaytime
      // 
      this.ButtonSetDelaytime.Location = new System.Drawing.Point(204, 17);
      this.ButtonSetDelaytime.Name = "ButtonSetDelaytime";
      this.ButtonSetDelaytime.Size = new System.Drawing.Size(50, 21);
      this.ButtonSetDelaytime.TabIndex = 15;
      this.ButtonSetDelaytime.Text = "Set";
      this.ButtonSetDelaytime.UseVisualStyleBackColor = true;
      this.ButtonSetDelaytime.Click += new System.EventHandler(this.ButtonSetDelaytime_Click);
      // 
      // ButtonReset_All
      // 
      this.ButtonReset_All.Location = new System.Drawing.Point(294, 26);
      this.ButtonReset_All.Name = "ButtonReset_All";
      this.ButtonReset_All.Size = new System.Drawing.Size(140, 30);
      this.ButtonReset_All.TabIndex = 8;
      this.ButtonReset_All.Text = "Reset factory settings";
      this.ButtonReset_All.UseVisualStyleBackColor = true;
      this.ButtonReset_All.Click += new System.EventHandler(this.ButtonReset_All_Click);
      // 
      // ButtonGetOutputFormat
      // 
      this.ButtonGetOutputFormat.Location = new System.Drawing.Point(148, 16);
      this.ButtonGetOutputFormat.Name = "ButtonGetOutputFormat";
      this.ButtonGetOutputFormat.Size = new System.Drawing.Size(50, 21);
      this.ButtonGetOutputFormat.TabIndex = 17;
      this.ButtonGetOutputFormat.Text = "Get";
      this.ButtonGetOutputFormat.UseVisualStyleBackColor = true;
      this.ButtonGetOutputFormat.Click += new System.EventHandler(this.ButtonGetOutputFormat_Click);
      // 
      // LabelBaudrate
      // 
      this.LabelBaudrate.Location = new System.Drawing.Point(6, 51);
      this.LabelBaudrate.Name = "LabelBaudrate";
      this.LabelBaudrate.Size = new System.Drawing.Size(60, 16);
      this.LabelBaudrate.TabIndex = 7;
      this.LabelBaudrate.Text = "Baudrate";
      // 
      // ButtonConnect
      // 
      this.ButtonConnect.BackColor = System.Drawing.SystemColors.Control;
      this.ButtonConnect.Location = new System.Drawing.Point(6, 82);
      this.ButtonConnect.Name = "ButtonConnect";
      this.ButtonConnect.Size = new System.Drawing.Size(138, 35);
      this.ButtonConnect.TabIndex = 2;
      this.ButtonConnect.Text = "Connect";
      this.ButtonConnect.UseVisualStyleBackColor = false;
      this.ButtonConnect.Click += new System.EventHandler(this.ButtonConnect_Click);
      // 
      // ComboBoxBaudrate
      // 
      this.ComboBoxBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.ComboBoxBaudrate.FormattingEnabled = true;
      this.ComboBoxBaudrate.Location = new System.Drawing.Point(69, 46);
      this.ComboBoxBaudrate.Name = "ComboBoxBaudrate";
      this.ComboBoxBaudrate.Size = new System.Drawing.Size(75, 21);
      this.ComboBoxBaudrate.TabIndex = 5;
      // 
      // TimerColorNumber
      // 
      this.TimerColorNumber.Interval = 250;
      this.TimerColorNumber.Tick += new System.EventHandler(this.TimerColorNumber_Tick);
      // 
      // LabelComport
      // 
      this.LabelComport.Location = new System.Drawing.Point(6, 23);
      this.LabelComport.Name = "LabelComport";
      this.LabelComport.Size = new System.Drawing.Size(60, 16);
      this.LabelComport.TabIndex = 6;
      this.LabelComport.Text = "Comport";
      // 
      // GroupBoxCommands
      // 
      this.GroupBoxCommands.Controls.Add(this.GroupBoxConfiguration);
      this.GroupBoxCommands.Controls.Add(this.GroupBoxDedicatedCommands);
      this.GroupBoxCommands.Controls.Add(this.GroupBoxGenericCommands);
      this.GroupBoxCommands.Location = new System.Drawing.Point(12, 138);
      this.GroupBoxCommands.Name = "GroupBoxCommands";
      this.GroupBoxCommands.Size = new System.Drawing.Size(636, 308);
      this.GroupBoxCommands.TabIndex = 18;
      this.GroupBoxCommands.TabStop = false;
      // 
      // GroupBoxConfiguration
      // 
      this.GroupBoxConfiguration.Controls.Add(this.GroupBoxCfgOutputFormat);
      this.GroupBoxConfiguration.Controls.Add(this.ButtonReset_All);
      this.GroupBoxConfiguration.Controls.Add(this.GroupBoxCfgDelayTime);
      this.GroupBoxConfiguration.Controls.Add(this.GroupBoxCfgSerialBaudrate);
      this.GroupBoxConfiguration.Location = new System.Drawing.Point(7, 110);
      this.GroupBoxConfiguration.Name = "GroupBoxConfiguration";
      this.GroupBoxConfiguration.Size = new System.Drawing.Size(473, 192);
      this.GroupBoxConfiguration.TabIndex = 25;
      this.GroupBoxConfiguration.TabStop = false;
      this.GroupBoxConfiguration.Text = "Configuration";
      // 
      // GroupBoxCfgOutputFormat
      // 
      this.GroupBoxCfgOutputFormat.Controls.Add(this.ButtonSetOutputFormat);
      this.GroupBoxCfgOutputFormat.Controls.Add(this.ComboBoxCfgOutputFormat);
      this.GroupBoxCfgOutputFormat.Controls.Add(this.ButtonGetOutputFormat);
      this.GroupBoxCfgOutputFormat.Location = new System.Drawing.Point(6, 19);
      this.GroupBoxCfgOutputFormat.Name = "GroupBoxCfgOutputFormat";
      this.GroupBoxCfgOutputFormat.Size = new System.Drawing.Size(282, 47);
      this.GroupBoxCfgOutputFormat.TabIndex = 13;
      this.GroupBoxCfgOutputFormat.TabStop = false;
      this.GroupBoxCfgOutputFormat.Text = "OutputFormat";
      // 
      // ButtonSetOutputFormat
      // 
      this.ButtonSetOutputFormat.Location = new System.Drawing.Point(204, 16);
      this.ButtonSetOutputFormat.Name = "ButtonSetOutputFormat";
      this.ButtonSetOutputFormat.Size = new System.Drawing.Size(50, 21);
      this.ButtonSetOutputFormat.TabIndex = 18;
      this.ButtonSetOutputFormat.Text = "Set";
      this.ButtonSetOutputFormat.UseVisualStyleBackColor = true;
      this.ButtonSetOutputFormat.Click += new System.EventHandler(this.ButtonSetOutputFormat_Click);
      // 
      // ComboBoxCfgOutputFormat
      // 
      this.ComboBoxCfgOutputFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.ComboBoxCfgOutputFormat.FormattingEnabled = true;
      this.ComboBoxCfgOutputFormat.Location = new System.Drawing.Point(7, 17);
      this.ComboBoxCfgOutputFormat.Name = "ComboBoxCfgOutputFormat";
      this.ComboBoxCfgOutputFormat.Size = new System.Drawing.Size(100, 21);
      this.ComboBoxCfgOutputFormat.TabIndex = 16;
      // 
      // GroupBoxCfgSerialBaudrate
      // 
      this.GroupBoxCfgSerialBaudrate.Controls.Add(this.ButtonSetSerialBaudrate);
      this.GroupBoxCfgSerialBaudrate.Controls.Add(this.ComboBoxCfgSerialBaudrate);
      this.GroupBoxCfgSerialBaudrate.Controls.Add(this.ButtonGetSerialBaudrate);
      this.GroupBoxCfgSerialBaudrate.Location = new System.Drawing.Point(6, 121);
      this.GroupBoxCfgSerialBaudrate.Name = "GroupBoxCfgSerialBaudrate";
      this.GroupBoxCfgSerialBaudrate.Size = new System.Drawing.Size(282, 47);
      this.GroupBoxCfgSerialBaudrate.TabIndex = 19;
      this.GroupBoxCfgSerialBaudrate.TabStop = false;
      this.GroupBoxCfgSerialBaudrate.Text = "Serial Baudrate";
      // 
      // ButtonSetSerialBaudrate
      // 
      this.ButtonSetSerialBaudrate.Location = new System.Drawing.Point(204, 17);
      this.ButtonSetSerialBaudrate.Name = "ButtonSetSerialBaudrate";
      this.ButtonSetSerialBaudrate.Size = new System.Drawing.Size(50, 21);
      this.ButtonSetSerialBaudrate.TabIndex = 18;
      this.ButtonSetSerialBaudrate.Text = "Set";
      this.ButtonSetSerialBaudrate.UseVisualStyleBackColor = true;
      this.ButtonSetSerialBaudrate.Click += new System.EventHandler(this.ButtonSetSerialBaudrate_Click);
      // 
      // ComboBoxCfgSerialBaudrate
      // 
      this.ComboBoxCfgSerialBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.ComboBoxCfgSerialBaudrate.FormattingEnabled = true;
      this.ComboBoxCfgSerialBaudrate.Location = new System.Drawing.Point(7, 17);
      this.ComboBoxCfgSerialBaudrate.Name = "ComboBoxCfgSerialBaudrate";
      this.ComboBoxCfgSerialBaudrate.Size = new System.Drawing.Size(100, 21);
      this.ComboBoxCfgSerialBaudrate.TabIndex = 16;
      // 
      // ButtonGetSerialBaudrate
      // 
      this.ButtonGetSerialBaudrate.Location = new System.Drawing.Point(148, 17);
      this.ButtonGetSerialBaudrate.Name = "ButtonGetSerialBaudrate";
      this.ButtonGetSerialBaudrate.Size = new System.Drawing.Size(50, 21);
      this.ButtonGetSerialBaudrate.TabIndex = 17;
      this.ButtonGetSerialBaudrate.Text = "Get";
      this.ButtonGetSerialBaudrate.UseVisualStyleBackColor = true;
      this.ButtonGetSerialBaudrate.Click += new System.EventHandler(this.ButtonGetSerialBaudrate_Click);
      // 
      // GroupBoxConnection
      // 
      this.GroupBoxConnection.Controls.Add(this.LabelBaudrate);
      this.GroupBoxConnection.Controls.Add(this.LabelComport);
      this.GroupBoxConnection.Controls.Add(this.ButtonConnect);
      this.GroupBoxConnection.Controls.Add(this.ComboBoxBaudrate);
      this.GroupBoxConnection.Controls.Add(this.ComboBoxPorts);
      this.GroupBoxConnection.Location = new System.Drawing.Point(498, 6);
      this.GroupBoxConnection.Name = "GroupBoxConnection";
      this.GroupBoxConnection.Size = new System.Drawing.Size(150, 126);
      this.GroupBoxConnection.TabIndex = 17;
      this.GroupBoxConnection.TabStop = false;
      this.GroupBoxConnection.Text = "Connection";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(655, 489);
      this.Controls.Add(this.GroupBoxTagnumber);
      this.Controls.Add(this.StatusStrip1);
      this.Controls.Add(this.GroupBoxCommands);
      this.Controls.Add(this.GroupBoxConnection);
      this.MaximizeBox = false;
      this.Name = "Form1";
      this.Text = "ASR550example_CS";
      this.Load += new System.EventHandler(this.Form1_Load);
      this.GroupBoxIsoNumbers.ResumeLayout(false);
      this.GroupBoxTagnumber.ResumeLayout(false);
      this.StatusStrip1.ResumeLayout(false);
      this.StatusStrip1.PerformLayout();
      this.GroupBoxDedicatedCommands.ResumeLayout(false);
      this.GroupBoxGenericCommands.ResumeLayout(false);
      this.GroupBoxCfgDelayTime.ResumeLayout(false);
      this.GroupBoxCommands.ResumeLayout(false);
      this.GroupBoxConfiguration.ResumeLayout(false);
      this.GroupBoxCfgOutputFormat.ResumeLayout(false);
      this.GroupBoxCfgSerialBaudrate.ResumeLayout(false);
      this.GroupBoxConnection.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    internal System.Windows.Forms.Label Label1;
    internal System.Windows.Forms.CheckBox CheckBoxDataBlockPresent;
    internal System.Windows.Forms.Label LabelCountryCode;
    internal System.Windows.Forms.ComboBox ComboBoxPorts;
    internal System.Windows.Forms.Label LabelRetaggingCounter;
    internal System.Windows.Forms.Label Label3;
    internal System.Windows.Forms.GroupBox GroupBoxIsoNumbers;
    internal System.Windows.Forms.Label Label7;
    internal System.Windows.Forms.Label LabelID;
    internal System.Windows.Forms.Label LabelReservedZone;
    internal System.Windows.Forms.Label Label4;
    internal System.Windows.Forms.Label Label6;
    internal System.Windows.Forms.Label LabelTagType;
    internal System.Windows.Forms.Label LabelUserInformation;
    internal System.Windows.Forms.CheckBox CheckBoxAnimalTag;
    internal System.Windows.Forms.Label Label5;
    internal System.Windows.Forms.Button ButtonGet_AntennaStatus;
    internal System.Windows.Forms.GroupBox GroupBoxTagnumber;
    internal System.Windows.Forms.Label LabelTagnumber;
    internal System.Windows.Forms.StatusStrip StatusStrip1;
    internal System.Windows.Forms.ToolStripStatusLabel ToolStripStatusLabel1;
    internal System.Windows.Forms.GroupBox GroupBoxDedicatedCommands;
    internal System.Windows.Forms.Button ButtonGetReaderVersion;
    internal System.Windows.Forms.Button ButtonStart_FastAutotuning;
    internal System.Windows.Forms.Button ButtonGetReaderSerialNumber;
    internal System.Windows.Forms.Button ButtonDevice_Check;
    internal System.Windows.Forms.GroupBox GroupBoxGenericCommands;
    internal System.Windows.Forms.Button ButtonExecuteCommand1;
    internal System.Windows.Forms.Button ButtonGetData;
    internal System.Windows.Forms.Button ButtonExecuteCommand2;
    internal System.Windows.Forms.ComboBox ComboBoxCfgDelayTime;
    internal System.Windows.Forms.GroupBox GroupBoxCfgDelayTime;
    internal System.Windows.Forms.Button ButtonGetDelaytime;
    internal System.Windows.Forms.Button ButtonSetDelaytime;
    internal System.Windows.Forms.Button ButtonReset_All;
    internal System.Windows.Forms.Button ButtonGetOutputFormat;
    internal System.Windows.Forms.Label LabelBaudrate;
    internal System.Windows.Forms.Button ButtonConnect;
    internal System.Windows.Forms.ComboBox ComboBoxBaudrate;
    internal System.Windows.Forms.Timer TimerColorNumber;
    internal System.Windows.Forms.Label LabelComport;
    internal System.Windows.Forms.GroupBox GroupBoxCommands;
    internal System.Windows.Forms.GroupBox GroupBoxConfiguration;
    internal System.Windows.Forms.GroupBox GroupBoxCfgOutputFormat;
    internal System.Windows.Forms.Button ButtonSetOutputFormat;
    internal System.Windows.Forms.ComboBox ComboBoxCfgOutputFormat;
    internal System.Windows.Forms.GroupBox GroupBoxCfgSerialBaudrate;
    internal System.Windows.Forms.Button ButtonSetSerialBaudrate;
    internal System.Windows.Forms.ComboBox ComboBoxCfgSerialBaudrate;
    internal System.Windows.Forms.Button ButtonGetSerialBaudrate;
    internal System.Windows.Forms.GroupBox GroupBoxConnection;
  }
}

