/*
 * Sample application demonstrating the use of the RFIDReader class with ASR550
 * (c) 2014 Agrident
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Agrident;

namespace ASR550example_CS
{
  public partial class Form1 : Form
  {
    // We need an instance of the RDIDReader class to control the ASR reader.
    private RFIDReader myReader;

    public Form1()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
      InitReader();
      InitGUI();

      // register our handler for reader messages
      myReader.TagdataReceived += new RFIDReader.TagdataReceivedEventHandler(myReader_TagdataReceived);
    }

    //------------------------------------------------------------------------------------------
    // create RFIDReader object and configure it
    //------------------------------------------------------------------------------------------
    void InitReader()
    {
      // We choose the constructor that takes a deviceID and the connectionType as parameters,
      // to make sure that the RFDIReader class can handle the ASR reader properly.
      myReader = new RFIDReader(RFIDReader.ReaderModelId.ASR550, RFIDReader.ConnectionTypes.UART);

      // By default the RFIDReader switches the RTS line of the UART to turn the reader on/off.
      // We don't need this here.
      myReader.PowerControlAuto = false;
      myReader.Baudrate = 9600;
    }

    //------------------------------------------------------------------------------------------
    // prepare form controls
    //------------------------------------------------------------------------------------------
    void InitGUI()
    {
      // fill list of available comports
      ComboBoxPorts.Items.AddRange(System.IO.Ports.SerialPort.GetPortNames());
      if (ComboBoxPorts.Items.Count > 0)
        ComboBoxPorts.SelectedIndex = 0;

      // fill baudrate combo
      ComboBoxBaudrate.Items.AddRange(new string[] {"9600","19200","38400","57600","115200"});
      ComboBoxBaudrate.SelectedIndex = 0;

      // fill combobox with delay time values
      for (int i = 0; i <= 255; i++)
      {
        // the delay time is defined in units of 50ms
        ComboBoxCfgDelayTime.Items.Add(string.Format("{0}ms", i * 50));
      }

      // fill combox box with reader output formats
      // the register values are taken from the ASR protocol description
      MyItem[] outputFormats = {
        new MyItem("ASCII", 0x1),
        new MyItem("Byte", 0x2),
        new MyItem("Compact", 0x3),
        new MyItem("ISO_24631", 0x4),
        new MyItem("Raw data", 0x6),
        new MyItem("Short ASCII 15", 0x7),
        new MyItem("NLIS", 0x8),
        new MyItem("Custom Format", 0x9),
        new MyItem("Short ASCII 16", 0x17),
        new MyItem("SCP", 0x21)
      };
      ComboBoxCfgOutputFormat.Items.AddRange(outputFormats);

      // fill combox box with reader baudrates
      ComboBoxCfgSerialBaudrate.Items.AddRange(new string[] { "9600", "19200", "38400", "57600", "115200" });
    }

    //------------------------------------------------------------------------------------------
    // change form controls according to the serial port state
    //------------------------------------------------------------------------------------------
    private void UpdateGUI()
    {
      bool enable = myReader.PortOpen;
      ButtonConnect.Text = (enable ? "Disconnect" : "Connect");
      ComboBoxPorts.Enabled = !enable;
      ComboBoxBaudrate.Enabled = !enable;
      GroupBoxCommands.Enabled = enable;
    }


    //------------------------------------------------------------------------------------------
    // open/close serial port for reader communication
    //------------------------------------------------------------------------------------------
    private void ButtonConnect_Click(object sender, EventArgs e)
    {
      if( myReader.PortOpen)
      {
        myReader.PortOpen = false;
      }
      else
      {
        myReader.PortName = ComboBoxPorts.Text;
        myReader.Baudrate = Convert.ToInt32(ComboBoxBaudrate.Text);
        myReader.PortOpen = true;
      }
      UpdateGUI();
    }

    private void ButtonGetReaderVersion_Click(object sender, EventArgs e)
    {
      requestReaderFirmwareVersion();
    }

    //------------------------------------------------------------------------------------------
    // request firmware version from reader
    //------------------------------------------------------------------------------------------
    void requestReaderFirmwareVersion()
    {
      show_operation_start("Get_Version...");

      bool result = false;
      string strVersion = "";

      try
      {
        result = myReader.GetVersion(ref strVersion);
      }
      catch(Exception ex)
      {
        MessageBox.Show(ex.Message, "Get_Version", MessageBoxButtons.OK, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1);
      }

      show_operation_stop(result, "Get_Version", strVersion);
    }

    private void ButtonGetReaderSerialNumber_Click(object sender, EventArgs e)
    {
      requestReaderSerialNumber();
    }

    //------------------------------------------------------------------------------------------
    // request serial number from reader and display it
    //------------------------------------------------------------------------------------------
    void requestReaderSerialNumber()
    {
      show_operation_start("Get_SNR...");

      // String to recieve the serial number
      string retString = "";

      // Usually we would use the DLL function *Get_SNR* to request the serial number.
      // For demonstration purposes we use the generic function *GetString* in this example
      bool result = myReader.GetString(ref retString,(byte)RFIDReader.MessageId.GET_SNR );

      show_operation_stop(result, "Get_SNR", retString);
    }

    private void ButtonReset_All_Click(object sender, EventArgs e)
    {
      Reset_ALL();
    }

    //------------------------------------------------------------------------------------------
    // Reset the reader to factory settings
    //------------------------------------------------------------------------------------------
    void Reset_ALL()
    {
      show_operation_start("Reset_ALL...");

      bool result = myReader.ExecuteCommand((byte)RFIDReader.MessageId.RESET_ALL);

      show_operation_stop(result, "Reset_All");
    }

    //------------------------------------------------------------------------------------------
    // Send a Start_FastAutotuning command 
    //------------------------------------------------------------------------------------------
    private void ButtonStart_FastAutotuning_Click(object sender, EventArgs e)
    {
      show_operation_start("Auto tuning...");

      bool result = myReader.ASR_Start_FastAutotuning();

      show_operation_stop(result, "Auto tuning");
    }

    private void ButtonDevice_Check_Click(object sender, EventArgs e)
    {
      Device_Check();
    }

    //------------------------------------------------------------------------------------------
    // Request various voltages from the reader
    //------------------------------------------------------------------------------------------
    void Device_Check()
    {
      show_operation_start("Device_Check...");

      // Request data from reader
      RFIDReader.ASR_struct_Device_Check deviceCheck = new RFIDReader.ASR_struct_Device_Check();
      bool result = myReader.ASR_Device_Check(ref deviceCheck);

      show_operation_stop(result, "Device_Check", myReader.MsgStringHex());

      if(result == true)
      {
        // show values
        string s = String.Format( 
          "Vin = {1}mV{0}Vrf = {2}mV{0}Vant = {3}V{0}Phase = {4}�", 
          "\r\n\r\n", 
          deviceCheck.inputVoltage, 
          deviceCheck.transmitterVoltage, 
          deviceCheck.antennaVoltage, 
          deviceCheck.phase);

        MessageBox.Show(s ,"Device_Check",MessageBoxButtons.OK,MessageBoxIcon.Information);

      }
    }

    private void ButtonGet_AntennaStatus_Click(object sender, EventArgs e)
    {
      Get_AntennaStatus();
    }

    //------------------------------------------------------------------------------------------
    // Request various antenna parameters from the reader
    //------------------------------------------------------------------------------------------
    void Get_AntennaStatus()
    {
      show_operation_start("Get_AntennaStatus...");

      RFIDReader.ASR_struct_AntennaStatus antennaStatus = new RFIDReader.ASR_struct_AntennaStatus();
      bool result = myReader.ASR_Get_AntennaStatus(ref antennaStatus,1);

      show_operation_stop(result, "Get_AntennaStatus", myReader.MsgStringHex());

      if(result)
      {
        // show values
        string s = String.Format( 
              "Amplitude = {1}V{0}Phase = {2}�{0}CP FDX = {3}{0}CP HDX = {4}{0}Info = {5}", 
              "\r\n\r\n", 
              antennaStatus.antennaVoltage, 
              antennaStatus.phase, 
              antennaStatus.cp_fdx, 
              antennaStatus.cp_hdx, 
              antennaStatus.info);
        MessageBox.Show(s,"Get_AntennaStatus",MessageBoxButtons.OK,MessageBoxIcon.Information);
      }
    }

    //------------------------------------------------------------------------------------------
    // Execute ANY reader command
    //
    // The Reader supports quite a lot of commands.
    // Only a few of these commands have dedicated methods in the RFIDReader class.
    // You may execute any command that the reader supports using the generic method 
    // *ExecuteCommand*.
    // As an example we use it here to switch the antenna field ON/OFF.
    //------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------
    // Switch RF field ON using the generic command *ExecuteCommand*
    //------------------------------------------------------------------------------------------
    private void ButtonExecuteCommand1_Click(object sender, EventArgs e)
    {
      show_operation_start("Set_RF_Activation (ON)...");

      // The ASR protocol manual (12.18) tells us that the command to switch the antenna field
      // has command code 0x96 and takes one parameter that is 1 to switch the field ON.
      bool result = myReader.ExecuteCommand(0x96, 1);

      show_operation_stop(result, "Set_RF_Activation (ON)");
    }

    //------------------------------------------------------------------------------------------
    // Switch RF field OFF using the generic command *ExecuteCommand*
    //------------------------------------------------------------------------------------------
    private void ButtonExecuteCommand2_Click(object sender, EventArgs e)
    {
      show_operation_start("Set_RF_Activation (OFF)...");

      // The ASR protocol manual (12.18) tells us that the command to switch the antenna field
      // has command code 0x96 and takes one parameter that is 0 to switch the field OFF.
      bool result = myReader.ExecuteCommand(0x96, 0);

      show_operation_stop(result, "Set_RF_Activation (OFF)");
    }

    //------------------------------------------------------------------------------------------
    // Request ANY reader data
    //
    // You may execute any data requests that the reader supports using the generic method 
    // *GetData*.
    // As an example we use it here to request the antenna field status.
    //------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------
    // Request RF field ON/OFF status using generic method GetData
    //------------------------------------------------------------------------------------------
    private void ButtonGetData_Click(object sender, EventArgs e)
    {
      show_operation_start("Get_RF_Activation...");

      // We need an array that GetData can fill with the data provided by the reader
      byte[] returnData = new byte[] { 0 };

      // The ASR protocol manual (12.19) tells us that the command to request the antenna field status
      // has command code 0x97
      bool result = myReader.GetData(ref returnData, 0x97);

      show_operation_stop(result, "Get_RF_Activation", BitConverter.ToString(returnData));
    }

    //------------------------------------------------------------------------------------------
    // read tagnumbers 
    //------------------------------------------------------------------------------------------

    //------------------------------------------------------------------------------------------
    // The RFIDReader class fires this event when it received a tagnumber from the ABR200
    //------------------------------------------------------------------------------------------
    private void myReader_TagdataReceived(Agrident.RFIDReader.TAGINFOPTYPE tagInfo)
    {
      this.BeginInvoke(new RFIDReader.TagdataReceivedEventHandler(myTagdataReceivedHandler), tagInfo);
    }

    //------------------------------------------------------------------------------------------
    // Our handler to display received tag numbers
    //------------------------------------------------------------------------------------------
    private void myTagdataReceivedHandler(Agrident.RFIDReader.TAGINFOPTYPE tagdata)
    {
      // Discard any pending messages if the serial port is closed
      if (!myReader.PortOpen)
        return;

      // display the tag id
      LabelTagnumber.Text = tagdata.TagNumberString;

      // If the reader is configured for 
      //   output format = Byte (config register 0x32 = 0x02)
      // the reader provides the complete 64 bits of the transponder number.
      // In this case tagInfo.TagNumber64BitHex helds the 64 Bits as 16 hex digits
      // and the DLL provides the according ISO numbers.

      if(tagdata.TagNumber64BitHex.Length > 0)
      {
        LabelCountryCode.Text = tagdata.CountryCode.ToString();
        LabelID.Text = tagdata.NationalID.ToString();
        LabelTagType.Text = ((RFIDReader.TransponderType)(tagdata.TagType)).ToString();
        CheckBoxAnimalTag.Checked = tagdata.AnimalFlag == RFIDReader.AnimalTag.FlagSet;
        LabelUserInformation.Text = tagdata.UserInformationField.ToString();
        LabelReservedZone.Text = tagdata.ReservedZone.ToString();
        LabelRetaggingCounter.Text = tagdata.RetaggingCounter.ToString();
        CheckBoxDataBlockPresent.Checked = tagdata.DatablockPresent == RFIDReader.DataBlockPresentFlag.FlagSet;

        GroupBoxIsoNumbers.Visible = true;
      }
      else
      {
        GroupBoxIsoNumbers.Visible = false;
      }

      // hiLight tagnumber
      LabelTagnumber.BackColor = Color.Yellow;
      TimerColorNumber.Enabled = true;
    }

    //------------------------------------------------------------------------------------------
    // reader configuration
    //------------------------------------------------------------------------------------------

    // Config register adresses from ASR protocol description
    enum ConfigRegisters : byte
    {
	    Output_format = 0x32,
	    Delaytime = 0x35,
	    SerialBaudrate = 0x38
    }

    private void ButtonGetDelaytime_Click(object sender, EventArgs e)
    {
      GetDelaytime();
    }

    //------------------------------------------------------------------------------------------
    // request configured DelayTime from reader
    //------------------------------------------------------------------------------------------
    void GetDelaytime()
    {
      show_operation_start("GetCfg Delaytime...");

      byte registerValue = 0;
      bool result = myReader.GetCfg((byte)ConfigRegisters.Delaytime, ref registerValue);

      if(result==true)
      {
        // update combobox with received value
        ComboBoxCfgDelayTime.SelectedIndex = registerValue;
      }

      show_operation_stop(result, "GetCfg Delaytime", registerValue.ToString());
    }

    private void ButtonSetDelaytime_Click(object sender, EventArgs e)
    {
      SetDelaytime();
    }
    
    //------------------------------------------------------------------------------------------
    // configure DelayTime in reader
    //------------------------------------------------------------------------------------------
    void SetDelaytime()
    {
      if(ComboBoxCfgDelayTime.SelectedIndex < 0)
        return;

      show_operation_start("SetCfg Delaytime...");

      const byte registerAddress = (byte)ConfigRegisters.Delaytime;
      byte newRegisterValue = (byte)(ComboBoxCfgDelayTime.SelectedIndex);

      bool result = myReader.SetCfg(registerAddress, newRegisterValue,false);

      show_operation_stop(result, "SetCfg Delaytime");
    }

    private void ButtonGetOutputFormat_Click(object sender, EventArgs e)
    {
      GetOutputFormat();
    }

    //------------------------------------------------------------------------------------------
    // request configured outputFormat from reader
    //------------------------------------------------------------------------------------------
    void GetOutputFormat()
    {
      show_operation_start("GetCfg OutputFormat...");

      byte registerValue = 0;
      bool result = myReader.GetCfg((byte)ConfigRegisters.Output_format, ref registerValue);

      if(result==true)
      {
        // update comboxbox according to received value
        ComboBoxCfgOutputFormat.SelectedItem = null;
        foreach (MyItem outputFormat in ComboBoxCfgOutputFormat.Items) 
        {
	        if (outputFormat.ItemData == registerValue) 
          {
		        ComboBoxCfgOutputFormat.SelectedItem = outputFormat;
		        break; 
      	  }
        }
      }

      show_operation_stop(result, "GetCfg OutputFormat", registerValue.ToString());
    }

    private void ButtonSetOutputFormat_Click(object sender, EventArgs e)
    {
      SetOutputFormat();
    }

    //------------------------------------------------------------------------------------------
    // configure OutputFormat in reader
    //------------------------------------------------------------------------------------------
    void SetOutputFormat()
    {
        if(ComboBoxCfgOutputFormat.SelectedIndex < 0)
          return;

      show_operation_start("SetCfg OutputFormat...");

      const byte registerAdress = (byte)ConfigRegisters.Output_format;
      byte newRegisterValue = (byte)((MyItem)ComboBoxCfgOutputFormat.SelectedItem).ItemData;

      bool result = myReader.SetCfg(registerAdress, newRegisterValue, false);

      show_operation_stop(result, "SetCfg OutputFormat");
    }


    private void ButtonGetSerialBaudrate_Click(object sender, EventArgs e)
    {
      GetSerialBaudrate();
    }

    //------------------------------------------------------------------------------------------
    // request configured baudrate from reader
    //------------------------------------------------------------------------------------------
    void GetSerialBaudrate()
    {
      show_operation_start("GetCfg SerialBaudrate");

      byte registerValue = 0;
      bool result = myReader.GetCfg((byte)ConfigRegisters.SerialBaudrate, ref registerValue);

      if(result==true)
      {
        // update combobox from received value
        if(registerValue < ComboBoxCfgSerialBaudrate.Items.Count)
        {
          ComboBoxCfgSerialBaudrate.SelectedIndex = registerValue;
        }

      }

      show_operation_stop(result, "GetCfg SerialBaudrate", registerValue.ToString());
    }


    private void ButtonSetSerialBaudrate_Click(object sender, EventArgs e)
    {
      SetSerialBaudrate();
    }

    //------------------------------------------------------------------------------------------
    // configure Baudrate in reader
    //------------------------------------------------------------------------------------------
    void SetSerialBaudrate()
    {
      if(ComboBoxCfgSerialBaudrate.SelectedIndex < 0)
        return;

      show_operation_start("SetCfg SerialBaudrate...");

      const byte registerAddress = (byte)ConfigRegisters.SerialBaudrate;
      byte newRegisterValue = (byte)ComboBoxCfgSerialBaudrate.SelectedIndex;

      // Change configuration register
      // note: we have to supply parameter *savePermanent* = false, because configuration
      // settings are always permanent on ASR550
      bool result = myReader.SetCfg(registerAddress, newRegisterValue, false);

      show_operation_stop(result, "SetCfg SerialBaudrate");
    }

    //------------------------------------------------------------------------------------------
    // Helper functions to show status infos
    //------------------------------------------------------------------------------------------

    // remove hiLight from Tagnumber in TimerTick 
    private void TimerColorNumber_Tick(object sender, EventArgs e)
    {
      TimerColorNumber.Enabled = false;
      LabelTagnumber.BackColor = SystemColors.Control;
    }

    // show text in status line
    void show_operation_start(string text)
    {
      ToolStripStatusLabel1.Text = text;
      GroupBoxCommands.Enabled = false;
    }

    // show infos in status line
    void show_operation_stop(bool ok,string cmdInfo,string strResult)
    {
      string statusText;
      if(ok) 
      {
        if(strResult.Length > 0) {
          statusText = String.Format("{0}: success  -  received data: {1}", cmdInfo, strResult);
        }
        else
        {
          statusText = String.Format("{0}: success", cmdInfo);
        }
      }
      else
      {
        statusText = String.Format("{0}: failed ({1})", cmdInfo, myReader.LastError());
      }
      ToolStripStatusLabel1.Text = statusText;
      UpdateGUI();
    }

    void show_operation_stop(bool ok, string cmdInfo)
    {
      show_operation_stop(ok,cmdInfo,"");
    }

    //------------------------------------------------------------------------------------------
    // Helper class for combo box items
    //------------------------------------------------------------------------------------------
    private class MyItem
    {
      private string sName;
      private int iID;

      public MyItem()
      {
        sName = "";
        iID = 0;
      }

      public MyItem(string Name, int ID)
      {
        sName = Name;
        iID = ID;
      }

      public string Name
      {
        get { return sName; }
        set { sName = value; }
      }

      public Int32 ItemData
      {
        get { return iID; }
        set { iID = value; }
      }

      public override string ToString()
      {
        return sName;
      }
    }
  }
}
