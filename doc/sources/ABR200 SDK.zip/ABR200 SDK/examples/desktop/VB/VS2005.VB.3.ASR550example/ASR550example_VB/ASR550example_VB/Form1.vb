'
' Sample application demonstrating the use of the RFIDReader class with ASR550
' (c) 2014 Agrident 
'
Imports Agrident
Imports Agrident.RFIDReader

Public Class Form1

  ' We need an instance of the RDIDReader class to control the ASR reader.
  Dim WithEvents myReader As RFIDReader

  '------------------------------------------------------------------------------------------
  ' Close serial port on closing to avoid exceptions due to pending reader events 
  '------------------------------------------------------------------------------------------
  Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    myReader.PortOpen = False
  End Sub

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    InitReader()
    InitGUI()
    UpdateGUI()
  End Sub

  '------------------------------------------------------------------------------------------
  ' create RFIDReader object and configure it
  '------------------------------------------------------------------------------------------
  Private Sub InitReader()
    ' We choose the constructor that takes a deviceID and the connectionType as parameters,
    ' to make sure that the RFDIReader class can handle the ASR reader properly.
    myReader = New RFIDReader(ReaderModelId.ASR550, ConnectionTypes.UART)

    ' By default the RFIDReader switches the RTS line of the UART to turn the reader on/off.
    ' We don't need this here.
    myReader.PowerControlAuto = False
    myReader.Baudrate = 9600
  End Sub

  '------------------------------------------------------------------------------------------
  ' prepare form controls
  '------------------------------------------------------------------------------------------
  Private Sub InitGUI()
    ' fill list of available comports
    ComboBoxPorts.Items.AddRange(IO.Ports.SerialPort.GetPortNames())
    If ComboBoxPorts.Items.Count > 0 Then ComboBoxPorts.SelectedIndex = 0

    ' fill baudrate combo
    ComboBoxBaudrate.Items.AddRange(New String() {"9600", "19200", "38400", "57600", "115200"})
    ComboBoxBaudrate.SelectedIndex = 0

    ' fill combobox with delay time values
    For i As Integer = 0 To 255
      ' the delay time is defined in units of 50ms
      ComboBoxCfgDelayTime.Items.Add(String.Format("{0}ms", i * 50))
    Next

    ' fill combox box with reader output formats
    ' the register values are taken from the ASR protocol description
    Dim outputFormats As MyItem() = { _
      New MyItem("ASCII", &H1), _
      New MyItem("Byte", &H2), _
      New MyItem("Compact", &H3), _
      New MyItem("ISO_24631", &H4), _
      New MyItem("Raw data", &H6), _
      New MyItem("Short ASCII 15", &H7), _
      New MyItem("NLIS", &H8), _
      New MyItem("Custom Format", &H9), _
      New MyItem("Short ASCII 16", &H17), _
      New MyItem("SCP", &H21) _
    }
    ComboBoxCfgOutputFormat.Items.AddRange(outputFormats)

    ' fill combox box with reader baudrates
    ComboBoxCfgSerialBaudrate.Items.AddRange(New String() {"9600", "19200", "38400", "57600", "115200"})
  End Sub

  '------------------------------------------------------------------------------------------
  ' change form controls according to the serial port state
  '------------------------------------------------------------------------------------------
  Private Sub UpdateGUI()
    Dim enable As Boolean = myReader.PortOpen
    ButtonConnect.Text = IIf(enable, "Disconnect", "Connect")
    ComboBoxPorts.Enabled = Not enable
    ComboBoxBaudrate.Enabled = Not enable
    GroupBoxCommands.Enabled = enable
  End Sub

  '------------------------------------------------------------------------------------------
  ' open/close serial port for reader communication
  '------------------------------------------------------------------------------------------
  Private Sub ButtonConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonConnect.Click
    If myReader.PortOpen Then
      myReader.PortOpen = False
    Else
      myReader.PortName = ComboBoxPorts.Text
      myReader.Baudrate = ComboBoxBaudrate.Text
      myReader.PortOpen = True
    End If
    UpdateGUI()
  End Sub

  Private Sub ButtonGetReaderVersion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGetReaderVersion.Click
    requestReaderFirmwareVersion()
  End Sub

  '------------------------------------------------------------------------------------------
  ' request firmware version from reader
  '------------------------------------------------------------------------------------------
  Private Sub requestReaderFirmwareVersion()
    show_operation_start("Get_Version...")

    Dim result As Boolean = False
    Dim strVersion As String = ""

    Try
      result = myReader.GetVersion(strVersion)
    Catch ex As Exception
      MsgBox(ex.Message, MsgBoxStyle.Critical)
    End Try

    show_operation_stop(result, "Get_Version", strVersion)
  End Sub

  Private Sub ButtonGetReaderSerialNumber_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGetReaderSerialNumber.Click
    requestReaderSerialNumber()
  End Sub

  '------------------------------------------------------------------------------------------
  ' request serial number from reader and display it
  '------------------------------------------------------------------------------------------
  Private Sub requestReaderSerialNumber()
    show_operation_start("Get_SNR...")

    ' String to recieve the serial number
    Dim retString As String = ""

    ' Usually we would use the DLL function *Get_SNR* to request the serial number.
    ' For demonstration purposes we use the generic function *GetString* in this example
    Dim result As Boolean = myReader.GetString(retString, RFIDReader.MessageId.GET_SNR)

    show_operation_stop(result, "Get_SNR", retString)
  End Sub

  Private Sub ButtonReset_All_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonReset_All.Click
    Reset_ALL()
  End Sub

  '------------------------------------------------------------------------------------------
  ' Reset the reader to factory settings
  '------------------------------------------------------------------------------------------
  Private Sub Reset_ALL()
    show_operation_start("Reset_ALL...")

    Dim result As Boolean = myReader.ExecuteCommand(RFIDReader.MessageId.RESET_ALL)

    show_operation_stop(result, "Reset_All")
  End Sub

  '------------------------------------------------------------------------------------------
  ' Send a Start_FastAutotuning command 
  '------------------------------------------------------------------------------------------
  Private Sub ButtonStart_FastAutotuning_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonStart_FastAutotuning.Click
    show_operation_start("Auto tuning...")

    Dim result As Boolean = myReader.ASR_Start_FastAutotuning()

    show_operation_stop(result, "Auto tuning")
  End Sub

  Private Sub ButtonDevice_Check_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonDevice_Check.Click
    Device_Check()
  End Sub

  '------------------------------------------------------------------------------------------
  ' Request various voltages from the reader
  '------------------------------------------------------------------------------------------
  Private Sub Device_Check()
    show_operation_start("Device_Check...")

    ' Request data from reader
    Dim deviceCheck As RFIDReader.ASR_struct_Device_Check
    Dim result As Boolean = myReader.ASR_Device_Check(deviceCheck)

    show_operation_stop(result, "Device_Check", myReader.MsgStringHex)

    If result = True Then

      ' show values
      Dim s As String = String.Format( _
        "Vin = {1}mV{0}Vrf = {2}mV{0}Vant = {3}V{0}Phase = {4}�", _
        vbCrLf & vbCrLf, _
        deviceCheck.inputVoltage, _
        deviceCheck.transmitterVoltage, _
        deviceCheck.antennaVoltage, _
        deviceCheck.phase)

      MsgBox(s, MsgBoxStyle.Information, "Device_Check")

    End If
  End Sub

  Private Sub ButtonGet_AntennaStatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGet_AntennaStatus.Click
    Get_AntennaStatus()
  End Sub

  '------------------------------------------------------------------------------------------
  ' Request various antenna parameters from the reader
  '------------------------------------------------------------------------------------------
  Private Sub Get_AntennaStatus()
    show_operation_start("Get_AntennaStatus...")

    Dim antennaStatus As RFIDReader.ASR_struct_AntennaStatus
    Dim result As Boolean = myReader.ASR_Get_AntennaStatus(antennaStatus)

    show_operation_stop(result, "Get_AntennaStatus", myReader.MsgStringHex)

    If result Then
      ' show values
      Dim s As String = String.Format( _
            "Amplitude = {1}V{0}Phase = {2}�{0}CP FDX = {3}{0}CP HDX = {4}{0}Info = {5}", _
            vbCrLf & vbCrLf, _
            antennaStatus.antennaVoltage, _
            antennaStatus.phase, _
            antennaStatus.cp_fdx, _
            antennaStatus.cp_hdx, _
            antennaStatus.info)
      MsgBox(s, MsgBoxStyle.Information, "Get_AntennaStatus")
    End If
  End Sub

  '------------------------------------------------------------------------------------------
  ' Execute ANY reader command
  '
  ' The Reader supports quite a lot of commands.
  ' Only a few of these commands have dedicated methods in the RFIDReader class.
  ' You may execute any command that the reader supports using the generic method 
  ' *ExecuteCommand*.
  ' As an example we use it here to switch the antenna field ON/OFF.
  '------------------------------------------------------------------------------------------

  '------------------------------------------------------------------------------------------
  ' Switch RF field ON using the generic command *ExecuteCommand*
  '------------------------------------------------------------------------------------------
  Private Sub ButtonExecuteCommand1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonExecuteCommand1.Click
    show_operation_start("Set_RF_Activation (ON)...")

    ' The ASR protocol manual (12.18) tells us that the command to switch the antenna field
    ' has command code 0x96 and takes one parameter that is 1 to switch the field ON.
    Dim result As Boolean = myReader.ExecuteCommand(&H96, 1)

    show_operation_stop(result, "Set_RF_Activation (ON)")
  End Sub

  '------------------------------------------------------------------------------------------
  ' Switch RF field OFF using the generic command *ExecuteCommand*
  '------------------------------------------------------------------------------------------
  Private Sub ButtonExecuteCommand2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonExecuteCommand2.Click
    show_operation_start("Set_RF_Activation (OFF)...")

    ' The ASR protocol manual (12.18) tells us that the command to switch the antenna field
    ' has command code 0x96 and takes one parameter that is 0 to switch the field OFF.
    Dim result As Boolean = myReader.ExecuteCommand(&H96, 0)

    show_operation_stop(result, "Set_RF_Activation (OFF)")
  End Sub

  '------------------------------------------------------------------------------------------
  ' Request ANY reader data
  '
  ' You may execute any data requests that the reader supports using the generic method 
  ' *GetData*.
  ' As an example we use it here to request the antenna field status.
  '------------------------------------------------------------------------------------------

  '------------------------------------------------------------------------------------------
  ' Request RF field ON/OFF status using generic method GetData
  '------------------------------------------------------------------------------------------
  Private Sub ButtonGetData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGetData.Click
    show_operation_start("Get_RF_Activation...")

    ' We need an array that GetData can fill with the data provided by the reader
    Dim returnData(-1) As Byte

    ' The ASR protocol manual (12.19) tells us that the command to request the antenna field status
    ' has command code 0x97
    Dim result As Boolean = myReader.GetData(returnData, &H97)

    show_operation_stop(result, "Get_RF_Activation", BitConverter.ToString(returnData))
  End Sub

  '------------------------------------------------------------------------------------------
  ' read tagnumbers 
  '------------------------------------------------------------------------------------------

  '------------------------------------------------------------------------------------------
  ' The RFIDReader class fires this event when it received a tagnumber from the ABR200
  '------------------------------------------------------------------------------------------
  Private Sub myReader_TagdataReceived(ByVal tagInfo As Agrident.RFIDReader.TAGINFOPTYPE) Handles myReader.TagdataReceived
    Me.BeginInvoke(New TagdataReceivedEventHandler(AddressOf myTagdataReceivedHandler), tagInfo)
  End Sub

  '------------------------------------------------------------------------------------------
  ' Our handler to display received tag numbers
  '------------------------------------------------------------------------------------------
  Private Sub myTagdataReceivedHandler(ByVal tagdata As Agrident.RFIDReader.TAGINFOPTYPE)
    ' Discard any pending messages if we closed the port
    If myReader.PortOpen = False Then Exit Sub

    ' display the tag id
    LabelTagnumber.Text = tagdata.TagNumberString

    ' If the reader is configured for 
    '   output format = Byte (config register 0x32 = 0x02)
    ' the reader provides the complete 64 bits of the transponder number.
    ' In this case tagInfo.TagNumber64BitHex helds the 64 Bits as 16 hex digits
    ' and the DLL provides the according ISO numbers.

    If tagdata.TagNumber64BitHex.Length > 0 Then
      LabelCountryCode.Text = tagdata.CountryCode.ToString
      LabelID.Text = tagdata.NationalID.ToString
      LabelTagType.Text = CType(tagdata.TagType, TransponderType).ToString
      CheckBoxAnimalTag.Checked = tagdata.AnimalFlag = AnimalTag.FlagSet
      LabelUserInformation.Text = tagdata.UserInformationField.ToString
      LabelReservedZone.Text = tagdata.ReservedZone.ToString
      LabelRetaggingCounter.Text = tagdata.RetaggingCounter.ToString
      CheckBoxDataBlockPresent.Checked = tagdata.DatablockPresent = DataBlockPresentFlag.FlagSet

      GroupBoxIsoNumbers.Visible = True
    Else
      GroupBoxIsoNumbers.Visible = False
    End If

    ' hiLight tagnumber
    LabelTagnumber.BackColor = Color.Yellow
    TimerColorNumber.Enabled = True
  End Sub

  '------------------------------------------------------------------------------------------
  ' reader configuration
  '------------------------------------------------------------------------------------------

  ' Config register adresses from ASR protocol description
  Enum ConfigRegisters As Byte
    Output_format = &H32
    Delaytime = &H35
    SerialBaudrate = &H38
  End Enum

  Private Sub ButtonGetDelaytime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGetDelaytime.Click
    GetDelaytime()
  End Sub

  '------------------------------------------------------------------------------------------
  ' request configured DelayTime from reader
  '------------------------------------------------------------------------------------------
  Private Sub GetDelaytime()
    show_operation_start("GetCfg Delaytime...")

    Dim registerValue As Byte
    Dim result As Boolean = myReader.GetCfg(ConfigRegisters.Delaytime, registerValue)

    If result = True Then
      ' update combobox with received value
      ComboBoxCfgDelayTime.SelectedIndex = registerValue

    End If

    show_operation_stop(result, "GetCfg Delaytime", registerValue.ToString)
  End Sub

  Private Sub ButtonSetDelaytime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSetDelaytime.Click
    SetDelaytime()
  End Sub

  '------------------------------------------------------------------------------------------
  ' configure DelayTime in reader
  '------------------------------------------------------------------------------------------
  Private Sub SetDelaytime()
    If ComboBoxCfgDelayTime.SelectedIndex < 0 Then Exit Sub

    show_operation_start("SetCfg Delaytime...")

    Const registerAddress As Byte = ConfigRegisters.Delaytime
    Dim newRegisterValue = CByte(ComboBoxCfgDelayTime.SelectedIndex)

    Dim result As Boolean = myReader.SetCfg(registerAddress, newRegisterValue)

    show_operation_stop(result, "SetCfg Delaytime")
  End Sub

  Private Sub ButtonGetOutputFormat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGetOutputFormat.Click
    GetOutputFormat()
  End Sub

  '------------------------------------------------------------------------------------------
  ' request configured outputFormat from reader
  '------------------------------------------------------------------------------------------
  Private Sub GetOutputFormat()
    show_operation_start("GetCfg OutputFormat...")

    Dim registerValue As Byte
    Dim result As Boolean = myReader.GetCfg(ConfigRegisters.Output_format, registerValue)

    If result = True Then
      ' update comboxbox according to received value
      ComboBoxCfgOutputFormat.SelectedItem = Nothing
      For Each outputFormat As MyItem In ComboBoxCfgOutputFormat.Items
        If outputFormat.ItemData = registerValue Then
          ComboBoxCfgOutputFormat.SelectedItem = outputFormat
          Exit For
        End If
      Next

    End If

    show_operation_stop(result, "GetCfg OutputFormat", registerValue.ToString)
  End Sub

  Private Sub ButtonSetOutputFormat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSetOutputFormat.Click
    SetOutputFormat()
  End Sub

  '------------------------------------------------------------------------------------------
  ' configure OutputFormat in reader
  '------------------------------------------------------------------------------------------
  Private Sub SetOutputFormat()
    If ComboBoxCfgOutputFormat.SelectedIndex < 0 Then Exit Sub

    show_operation_start("SetCfg OutputFormat...")

    Dim registerAdress As Byte = ConfigRegisters.Output_format
    Dim newRegisterValue As Byte = CType(ComboBoxCfgOutputFormat.SelectedItem, MyItem).ItemData

    Dim result As Boolean = myReader.SetCfg(registerAdress, newRegisterValue)

    show_operation_stop(result, "SetCfg OutputFormat")
  End Sub

  Private Sub ButtonGetSerialBaudrate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonGetSerialBaudrate.Click
    GetSerialBaudrate()
  End Sub

  '------------------------------------------------------------------------------------------
  ' request configured baudrate from reader
  '------------------------------------------------------------------------------------------
  Private Sub GetSerialBaudrate()
    show_operation_start("GetCfg SerialBaudrate")

    Dim registerValue As Byte
    Dim result As Boolean = myReader.GetCfg(ConfigRegisters.SerialBaudrate, registerValue)

    If result = True Then
      ' update combobox from received value
      If registerValue < ComboBoxCfgSerialBaudrate.Items.Count Then
        ComboBoxCfgSerialBaudrate.SelectedIndex = registerValue
      End If

    End If

    show_operation_stop(result, "GetCfg SerialBaudrate", registerValue.ToString)
  End Sub

  Private Sub ButtonSetSerialBaudrate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonSetSerialBaudrate.Click
    SetSerialBaudrate()
  End Sub

  '------------------------------------------------------------------------------------------
  ' configure Baudrate in reader
  '------------------------------------------------------------------------------------------
  Private Sub SetSerialBaudrate()
    If ComboBoxCfgSerialBaudrate.SelectedIndex < 0 Then Exit Sub

    show_operation_start("SetCfg SerialBaudrate...")

    Const registerAddress As Byte = ConfigRegisters.SerialBaudrate
    Dim newRegisterValue As Byte = CByte(ComboBoxCfgSerialBaudrate.SelectedIndex)

    Dim result As Boolean = myReader.SetCfg(registerAddress, newRegisterValue)

    show_operation_stop(result, "SetCfg SerialBaudrate")
  End Sub

  '------------------------------------------------------------------------------------------
  ' Helper functions to show status infos
  '------------------------------------------------------------------------------------------

  ' remove hiLight from Tagnumber in TimerTick 
  Private Sub TimerColorNumber_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerColorNumber.Tick
    TimerColorNumber.Enabled = False
    LabelTagnumber.BackColor = SystemColors.Control
  End Sub

  ' show text in status line
  Private Sub show_operation_start(ByVal text As String)
    ToolStripStatusLabel1.Text = text
    GroupBoxCommands.Enabled = False
  End Sub

  ' show infos in status line
  Private Sub show_operation_stop(ByVal ok As Boolean, ByVal cmdInfo As String, Optional ByVal strResult As String = "")
    Dim statusText As String
    If ok Then
      If strResult.Length > 0 Then
        statusText = String.Format("{0}: success  -  received data: {1}", cmdInfo, strResult)
      Else
        statusText = String.Format("{0}: success", cmdInfo)
      End If
    Else
      statusText = String.Format("{0}: failed ({1})", cmdInfo, myReader.LastError)
    End If
    ToolStripStatusLabel1.Text = statusText
    UpdateGUI()
  End Sub

  '------------------------------------------------------------------------------------------
  ' Helper class for combo box items
  '------------------------------------------------------------------------------------------
  Private Class MyItem
    Private sName As String
    Private iID As Integer

    Public Sub New()
      sName = ""
      iID = 0
    End Sub

    Public Sub New(ByVal Name As String, ByVal ID As Integer)
      sName = Name
      iID = ID
    End Sub

    Public Property Name() As String
      Get
        Return sName
      End Get
      Set(ByVal sValue As String)
        sName = sValue
      End Set
    End Property

    Public Property ItemData() As Int32
      Get
        Return iID
      End Get
      Set(ByVal iValue As Int32)
        iID = iValue
      End Set
    End Property

    Public Overrides Function ToString() As String
      Return sName
    End Function
  End Class
End Class
