<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container
    Me.ComboBoxPorts = New System.Windows.Forms.ComboBox
    Me.ButtonConnect = New System.Windows.Forms.Button
    Me.ButtonGetReaderVersion = New System.Windows.Forms.Button
    Me.LabelTagnumber = New System.Windows.Forms.Label
    Me.TimerColorNumber = New System.Windows.Forms.Timer(Me.components)
    Me.ComboBoxBaudrate = New System.Windows.Forms.ComboBox
    Me.GroupBoxConnection = New System.Windows.Forms.GroupBox
    Me.LabelBaudrate = New System.Windows.Forms.Label
    Me.LabelComport = New System.Windows.Forms.Label
    Me.ButtonGetReaderSerialNumber = New System.Windows.Forms.Button
    Me.ButtonReset_All = New System.Windows.Forms.Button
    Me.ButtonStart_FastAutotuning = New System.Windows.Forms.Button
    Me.ButtonDevice_Check = New System.Windows.Forms.Button
    Me.GroupBoxCommands = New System.Windows.Forms.GroupBox
    Me.GroupBoxConfiguration = New System.Windows.Forms.GroupBox
    Me.GroupBoxCfgOutputFormat = New System.Windows.Forms.GroupBox
    Me.ButtonSetOutputFormat = New System.Windows.Forms.Button
    Me.ComboBoxCfgOutputFormat = New System.Windows.Forms.ComboBox
    Me.ButtonGetOutputFormat = New System.Windows.Forms.Button
    Me.GroupBoxCfgDelayTime = New System.Windows.Forms.GroupBox
    Me.ComboBoxCfgDelayTime = New System.Windows.Forms.ComboBox
    Me.ButtonGetDelaytime = New System.Windows.Forms.Button
    Me.ButtonSetDelaytime = New System.Windows.Forms.Button
    Me.GroupBoxCfgSerialBaudrate = New System.Windows.Forms.GroupBox
    Me.ButtonSetSerialBaudrate = New System.Windows.Forms.Button
    Me.ComboBoxCfgSerialBaudrate = New System.Windows.Forms.ComboBox
    Me.ButtonGetSerialBaudrate = New System.Windows.Forms.Button
    Me.GroupBoxDedicatedCommands = New System.Windows.Forms.GroupBox
    Me.ButtonGet_AntennaStatus = New System.Windows.Forms.Button
    Me.GroupBoxGenericCommands = New System.Windows.Forms.GroupBox
    Me.ButtonExecuteCommand1 = New System.Windows.Forms.Button
    Me.ButtonGetData = New System.Windows.Forms.Button
    Me.ButtonExecuteCommand2 = New System.Windows.Forms.Button
    Me.Button2 = New System.Windows.Forms.Button
    Me.GroupBoxTagnumber = New System.Windows.Forms.GroupBox
    Me.GroupBoxIsoNumbers = New System.Windows.Forms.GroupBox
    Me.Label1 = New System.Windows.Forms.Label
    Me.CheckBoxDataBlockPresent = New System.Windows.Forms.CheckBox
    Me.LabelCountryCode = New System.Windows.Forms.Label
    Me.LabelRetaggingCounter = New System.Windows.Forms.Label
    Me.Label3 = New System.Windows.Forms.Label
    Me.Label7 = New System.Windows.Forms.Label
    Me.LabelID = New System.Windows.Forms.Label
    Me.LabelReservedZone = New System.Windows.Forms.Label
    Me.Label4 = New System.Windows.Forms.Label
    Me.Label6 = New System.Windows.Forms.Label
    Me.LabelTagType = New System.Windows.Forms.Label
    Me.LabelUserInformation = New System.Windows.Forms.Label
    Me.CheckBoxAnimalTag = New System.Windows.Forms.CheckBox
    Me.Label5 = New System.Windows.Forms.Label
    Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
    Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
    Me.GroupBoxConnection.SuspendLayout()
    Me.GroupBoxCommands.SuspendLayout()
    Me.GroupBoxConfiguration.SuspendLayout()
    Me.GroupBoxCfgOutputFormat.SuspendLayout()
    Me.GroupBoxCfgDelayTime.SuspendLayout()
    Me.GroupBoxCfgSerialBaudrate.SuspendLayout()
    Me.GroupBoxDedicatedCommands.SuspendLayout()
    Me.GroupBoxGenericCommands.SuspendLayout()
    Me.GroupBoxTagnumber.SuspendLayout()
    Me.GroupBoxIsoNumbers.SuspendLayout()
    Me.StatusStrip1.SuspendLayout()
    Me.SuspendLayout()
    '
    'ComboBoxPorts
    '
    Me.ComboBoxPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.ComboBoxPorts.FormattingEnabled = True
    Me.ComboBoxPorts.Location = New System.Drawing.Point(69, 19)
    Me.ComboBoxPorts.Name = "ComboBoxPorts"
    Me.ComboBoxPorts.Size = New System.Drawing.Size(75, 21)
    Me.ComboBoxPorts.TabIndex = 1
    '
    'ButtonConnect
    '
    Me.ButtonConnect.BackColor = System.Drawing.SystemColors.Control
    Me.ButtonConnect.Location = New System.Drawing.Point(6, 82)
    Me.ButtonConnect.Name = "ButtonConnect"
    Me.ButtonConnect.Size = New System.Drawing.Size(138, 35)
    Me.ButtonConnect.TabIndex = 2
    Me.ButtonConnect.Text = "Connect"
    Me.ButtonConnect.UseVisualStyleBackColor = False
    '
    'ButtonGetReaderVersion
    '
    Me.ButtonGetReaderVersion.Location = New System.Drawing.Point(6, 19)
    Me.ButtonGetReaderVersion.Name = "ButtonGetReaderVersion"
    Me.ButtonGetReaderVersion.Size = New System.Drawing.Size(140, 30)
    Me.ButtonGetReaderVersion.TabIndex = 3
    Me.ButtonGetReaderVersion.Text = "Get firmware version"
    Me.ButtonGetReaderVersion.UseVisualStyleBackColor = True
    '
    'LabelTagnumber
    '
    Me.LabelTagnumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.LabelTagnumber.Location = New System.Drawing.Point(11, 16)
    Me.LabelTagnumber.Name = "LabelTagnumber"
    Me.LabelTagnumber.Size = New System.Drawing.Size(463, 21)
    Me.LabelTagnumber.TabIndex = 4
    Me.LabelTagnumber.Text = "Tagnumber goes here..."
    '
    'TimerColorNumber
    '
    Me.TimerColorNumber.Interval = 250
    '
    'ComboBoxBaudrate
    '
    Me.ComboBoxBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.ComboBoxBaudrate.FormattingEnabled = True
    Me.ComboBoxBaudrate.Location = New System.Drawing.Point(69, 46)
    Me.ComboBoxBaudrate.Name = "ComboBoxBaudrate"
    Me.ComboBoxBaudrate.Size = New System.Drawing.Size(75, 21)
    Me.ComboBoxBaudrate.TabIndex = 5
    '
    'GroupBoxConnection
    '
    Me.GroupBoxConnection.Controls.Add(Me.LabelBaudrate)
    Me.GroupBoxConnection.Controls.Add(Me.LabelComport)
    Me.GroupBoxConnection.Controls.Add(Me.ButtonConnect)
    Me.GroupBoxConnection.Controls.Add(Me.ComboBoxBaudrate)
    Me.GroupBoxConnection.Controls.Add(Me.ComboBoxPorts)
    Me.GroupBoxConnection.Location = New System.Drawing.Point(498, 12)
    Me.GroupBoxConnection.Name = "GroupBoxConnection"
    Me.GroupBoxConnection.Size = New System.Drawing.Size(150, 126)
    Me.GroupBoxConnection.TabIndex = 6
    Me.GroupBoxConnection.TabStop = False
    Me.GroupBoxConnection.Text = "Connection"
    '
    'LabelBaudrate
    '
    Me.LabelBaudrate.Location = New System.Drawing.Point(6, 51)
    Me.LabelBaudrate.Name = "LabelBaudrate"
    Me.LabelBaudrate.Size = New System.Drawing.Size(60, 16)
    Me.LabelBaudrate.TabIndex = 7
    Me.LabelBaudrate.Text = "Baudrate"
    '
    'LabelComport
    '
    Me.LabelComport.Location = New System.Drawing.Point(6, 23)
    Me.LabelComport.Name = "LabelComport"
    Me.LabelComport.Size = New System.Drawing.Size(60, 16)
    Me.LabelComport.TabIndex = 6
    Me.LabelComport.Text = "Comport"
    '
    'ButtonGetReaderSerialNumber
    '
    Me.ButtonGetReaderSerialNumber.Location = New System.Drawing.Point(152, 19)
    Me.ButtonGetReaderSerialNumber.Name = "ButtonGetReaderSerialNumber"
    Me.ButtonGetReaderSerialNumber.Size = New System.Drawing.Size(140, 30)
    Me.ButtonGetReaderSerialNumber.TabIndex = 7
    Me.ButtonGetReaderSerialNumber.Text = "Get reader serial No"
    Me.ButtonGetReaderSerialNumber.UseVisualStyleBackColor = True
    '
    'ButtonReset_All
    '
    Me.ButtonReset_All.Location = New System.Drawing.Point(294, 26)
    Me.ButtonReset_All.Name = "ButtonReset_All"
    Me.ButtonReset_All.Size = New System.Drawing.Size(140, 30)
    Me.ButtonReset_All.TabIndex = 8
    Me.ButtonReset_All.Text = "Reset factory settings"
    Me.ButtonReset_All.UseVisualStyleBackColor = True
    '
    'ButtonStart_FastAutotuning
    '
    Me.ButtonStart_FastAutotuning.Location = New System.Drawing.Point(298, 19)
    Me.ButtonStart_FastAutotuning.Name = "ButtonStart_FastAutotuning"
    Me.ButtonStart_FastAutotuning.Size = New System.Drawing.Size(140, 30)
    Me.ButtonStart_FastAutotuning.TabIndex = 9
    Me.ButtonStart_FastAutotuning.Text = "Auto tuning"
    Me.ButtonStart_FastAutotuning.UseVisualStyleBackColor = True
    '
    'ButtonDevice_Check
    '
    Me.ButtonDevice_Check.Location = New System.Drawing.Point(6, 55)
    Me.ButtonDevice_Check.Name = "ButtonDevice_Check"
    Me.ButtonDevice_Check.Size = New System.Drawing.Size(140, 30)
    Me.ButtonDevice_Check.TabIndex = 10
    Me.ButtonDevice_Check.Text = "Device_Check"
    Me.ButtonDevice_Check.UseVisualStyleBackColor = True
    '
    'GroupBoxCommands
    '
    Me.GroupBoxCommands.Controls.Add(Me.GroupBoxConfiguration)
    Me.GroupBoxCommands.Controls.Add(Me.GroupBoxDedicatedCommands)
    Me.GroupBoxCommands.Controls.Add(Me.GroupBoxGenericCommands)
    Me.GroupBoxCommands.Location = New System.Drawing.Point(12, 144)
    Me.GroupBoxCommands.Name = "GroupBoxCommands"
    Me.GroupBoxCommands.Size = New System.Drawing.Size(636, 308)
    Me.GroupBoxCommands.TabIndex = 11
    Me.GroupBoxCommands.TabStop = False
    '
    'GroupBoxConfiguration
    '
    Me.GroupBoxConfiguration.Controls.Add(Me.GroupBoxCfgOutputFormat)
    Me.GroupBoxConfiguration.Controls.Add(Me.ButtonReset_All)
    Me.GroupBoxConfiguration.Controls.Add(Me.GroupBoxCfgDelayTime)
    Me.GroupBoxConfiguration.Controls.Add(Me.GroupBoxCfgSerialBaudrate)
    Me.GroupBoxConfiguration.Location = New System.Drawing.Point(7, 110)
    Me.GroupBoxConfiguration.Name = "GroupBoxConfiguration"
    Me.GroupBoxConfiguration.Size = New System.Drawing.Size(473, 192)
    Me.GroupBoxConfiguration.TabIndex = 25
    Me.GroupBoxConfiguration.TabStop = False
    Me.GroupBoxConfiguration.Text = "Configuration"
    '
    'GroupBoxCfgOutputFormat
    '
    Me.GroupBoxCfgOutputFormat.Controls.Add(Me.ButtonSetOutputFormat)
    Me.GroupBoxCfgOutputFormat.Controls.Add(Me.ComboBoxCfgOutputFormat)
    Me.GroupBoxCfgOutputFormat.Controls.Add(Me.ButtonGetOutputFormat)
    Me.GroupBoxCfgOutputFormat.Location = New System.Drawing.Point(6, 19)
    Me.GroupBoxCfgOutputFormat.Name = "GroupBoxCfgOutputFormat"
    Me.GroupBoxCfgOutputFormat.Size = New System.Drawing.Size(282, 47)
    Me.GroupBoxCfgOutputFormat.TabIndex = 13
    Me.GroupBoxCfgOutputFormat.TabStop = False
    Me.GroupBoxCfgOutputFormat.Text = "OutputFormat"
    '
    'ButtonSetOutputFormat
    '
    Me.ButtonSetOutputFormat.Location = New System.Drawing.Point(204, 16)
    Me.ButtonSetOutputFormat.Name = "ButtonSetOutputFormat"
    Me.ButtonSetOutputFormat.Size = New System.Drawing.Size(50, 21)
    Me.ButtonSetOutputFormat.TabIndex = 18
    Me.ButtonSetOutputFormat.Text = "Set"
    Me.ButtonSetOutputFormat.UseVisualStyleBackColor = True
    '
    'ComboBoxCfgOutputFormat
    '
    Me.ComboBoxCfgOutputFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.ComboBoxCfgOutputFormat.FormattingEnabled = True
    Me.ComboBoxCfgOutputFormat.Location = New System.Drawing.Point(7, 17)
    Me.ComboBoxCfgOutputFormat.Name = "ComboBoxCfgOutputFormat"
    Me.ComboBoxCfgOutputFormat.Size = New System.Drawing.Size(100, 21)
    Me.ComboBoxCfgOutputFormat.TabIndex = 16
    '
    'ButtonGetOutputFormat
    '
    Me.ButtonGetOutputFormat.Location = New System.Drawing.Point(148, 16)
    Me.ButtonGetOutputFormat.Name = "ButtonGetOutputFormat"
    Me.ButtonGetOutputFormat.Size = New System.Drawing.Size(50, 21)
    Me.ButtonGetOutputFormat.TabIndex = 17
    Me.ButtonGetOutputFormat.Text = "Get"
    Me.ButtonGetOutputFormat.UseVisualStyleBackColor = True
    '
    'GroupBoxCfgDelayTime
    '
    Me.GroupBoxCfgDelayTime.Controls.Add(Me.ComboBoxCfgDelayTime)
    Me.GroupBoxCfgDelayTime.Controls.Add(Me.ButtonGetDelaytime)
    Me.GroupBoxCfgDelayTime.Controls.Add(Me.ButtonSetDelaytime)
    Me.GroupBoxCfgDelayTime.Location = New System.Drawing.Point(6, 72)
    Me.GroupBoxCfgDelayTime.Name = "GroupBoxCfgDelayTime"
    Me.GroupBoxCfgDelayTime.Size = New System.Drawing.Size(282, 43)
    Me.GroupBoxCfgDelayTime.TabIndex = 12
    Me.GroupBoxCfgDelayTime.TabStop = False
    Me.GroupBoxCfgDelayTime.Text = "DelayTime"
    '
    'ComboBoxCfgDelayTime
    '
    Me.ComboBoxCfgDelayTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.ComboBoxCfgDelayTime.FormattingEnabled = True
    Me.ComboBoxCfgDelayTime.Location = New System.Drawing.Point(7, 17)
    Me.ComboBoxCfgDelayTime.Name = "ComboBoxCfgDelayTime"
    Me.ComboBoxCfgDelayTime.Size = New System.Drawing.Size(99, 21)
    Me.ComboBoxCfgDelayTime.TabIndex = 13
    '
    'ButtonGetDelaytime
    '
    Me.ButtonGetDelaytime.Location = New System.Drawing.Point(148, 17)
    Me.ButtonGetDelaytime.Name = "ButtonGetDelaytime"
    Me.ButtonGetDelaytime.Size = New System.Drawing.Size(50, 21)
    Me.ButtonGetDelaytime.TabIndex = 14
    Me.ButtonGetDelaytime.Text = "Get"
    Me.ButtonGetDelaytime.UseVisualStyleBackColor = True
    '
    'ButtonSetDelaytime
    '
    Me.ButtonSetDelaytime.Location = New System.Drawing.Point(204, 17)
    Me.ButtonSetDelaytime.Name = "ButtonSetDelaytime"
    Me.ButtonSetDelaytime.Size = New System.Drawing.Size(50, 21)
    Me.ButtonSetDelaytime.TabIndex = 15
    Me.ButtonSetDelaytime.Text = "Set"
    Me.ButtonSetDelaytime.UseVisualStyleBackColor = True
    '
    'GroupBoxCfgSerialBaudrate
    '
    Me.GroupBoxCfgSerialBaudrate.Controls.Add(Me.ButtonSetSerialBaudrate)
    Me.GroupBoxCfgSerialBaudrate.Controls.Add(Me.ComboBoxCfgSerialBaudrate)
    Me.GroupBoxCfgSerialBaudrate.Controls.Add(Me.ButtonGetSerialBaudrate)
    Me.GroupBoxCfgSerialBaudrate.Location = New System.Drawing.Point(6, 121)
    Me.GroupBoxCfgSerialBaudrate.Name = "GroupBoxCfgSerialBaudrate"
    Me.GroupBoxCfgSerialBaudrate.Size = New System.Drawing.Size(282, 47)
    Me.GroupBoxCfgSerialBaudrate.TabIndex = 19
    Me.GroupBoxCfgSerialBaudrate.TabStop = False
    Me.GroupBoxCfgSerialBaudrate.Text = "Serial Baudrate"
    '
    'ButtonSetSerialBaudrate
    '
    Me.ButtonSetSerialBaudrate.Location = New System.Drawing.Point(204, 17)
    Me.ButtonSetSerialBaudrate.Name = "ButtonSetSerialBaudrate"
    Me.ButtonSetSerialBaudrate.Size = New System.Drawing.Size(50, 21)
    Me.ButtonSetSerialBaudrate.TabIndex = 18
    Me.ButtonSetSerialBaudrate.Text = "Set"
    Me.ButtonSetSerialBaudrate.UseVisualStyleBackColor = True
    '
    'ComboBoxCfgSerialBaudrate
    '
    Me.ComboBoxCfgSerialBaudrate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
    Me.ComboBoxCfgSerialBaudrate.FormattingEnabled = True
    Me.ComboBoxCfgSerialBaudrate.Location = New System.Drawing.Point(7, 17)
    Me.ComboBoxCfgSerialBaudrate.Name = "ComboBoxCfgSerialBaudrate"
    Me.ComboBoxCfgSerialBaudrate.Size = New System.Drawing.Size(100, 21)
    Me.ComboBoxCfgSerialBaudrate.TabIndex = 16
    '
    'ButtonGetSerialBaudrate
    '
    Me.ButtonGetSerialBaudrate.Location = New System.Drawing.Point(148, 17)
    Me.ButtonGetSerialBaudrate.Name = "ButtonGetSerialBaudrate"
    Me.ButtonGetSerialBaudrate.Size = New System.Drawing.Size(50, 21)
    Me.ButtonGetSerialBaudrate.TabIndex = 17
    Me.ButtonGetSerialBaudrate.Text = "Get"
    Me.ButtonGetSerialBaudrate.UseVisualStyleBackColor = True
    '
    'GroupBoxDedicatedCommands
    '
    Me.GroupBoxDedicatedCommands.Controls.Add(Me.ButtonGetReaderVersion)
    Me.GroupBoxDedicatedCommands.Controls.Add(Me.ButtonStart_FastAutotuning)
    Me.GroupBoxDedicatedCommands.Controls.Add(Me.ButtonGetReaderSerialNumber)
    Me.GroupBoxDedicatedCommands.Controls.Add(Me.ButtonDevice_Check)
    Me.GroupBoxDedicatedCommands.Controls.Add(Me.ButtonGet_AntennaStatus)
    Me.GroupBoxDedicatedCommands.Location = New System.Drawing.Point(7, 11)
    Me.GroupBoxDedicatedCommands.Name = "GroupBoxDedicatedCommands"
    Me.GroupBoxDedicatedCommands.Size = New System.Drawing.Size(473, 93)
    Me.GroupBoxDedicatedCommands.TabIndex = 24
    Me.GroupBoxDedicatedCommands.TabStop = False
    Me.GroupBoxDedicatedCommands.Text = "Dedicated commands"
    '
    'ButtonGet_AntennaStatus
    '
    Me.ButtonGet_AntennaStatus.Location = New System.Drawing.Point(152, 55)
    Me.ButtonGet_AntennaStatus.Name = "ButtonGet_AntennaStatus"
    Me.ButtonGet_AntennaStatus.Size = New System.Drawing.Size(140, 30)
    Me.ButtonGet_AntennaStatus.TabIndex = 11
    Me.ButtonGet_AntennaStatus.Text = "Get_AntennaStatus"
    Me.ButtonGet_AntennaStatus.UseVisualStyleBackColor = True
    '
    'GroupBoxGenericCommands
    '
    Me.GroupBoxGenericCommands.Controls.Add(Me.ButtonExecuteCommand1)
    Me.GroupBoxGenericCommands.Controls.Add(Me.ButtonGetData)
    Me.GroupBoxGenericCommands.Controls.Add(Me.ButtonExecuteCommand2)
    Me.GroupBoxGenericCommands.Location = New System.Drawing.Point(486, 11)
    Me.GroupBoxGenericCommands.Name = "GroupBoxGenericCommands"
    Me.GroupBoxGenericCommands.Size = New System.Drawing.Size(143, 155)
    Me.GroupBoxGenericCommands.TabIndex = 23
    Me.GroupBoxGenericCommands.TabStop = False
    Me.GroupBoxGenericCommands.Text = "Generic commands"
    '
    'ButtonExecuteCommand1
    '
    Me.ButtonExecuteCommand1.Location = New System.Drawing.Point(9, 19)
    Me.ButtonExecuteCommand1.Name = "ButtonExecuteCommand1"
    Me.ButtonExecuteCommand1.Size = New System.Drawing.Size(127, 30)
    Me.ButtonExecuteCommand1.TabIndex = 21
    Me.ButtonExecuteCommand1.Text = "RF field ON"
    Me.ButtonExecuteCommand1.UseVisualStyleBackColor = True
    '
    'ButtonGetData
    '
    Me.ButtonGetData.Location = New System.Drawing.Point(9, 91)
    Me.ButtonGetData.Name = "ButtonGetData"
    Me.ButtonGetData.Size = New System.Drawing.Size(127, 30)
    Me.ButtonGetData.TabIndex = 22
    Me.ButtonGetData.Text = "RF activation request"
    Me.ButtonGetData.UseVisualStyleBackColor = True
    '
    'ButtonExecuteCommand2
    '
    Me.ButtonExecuteCommand2.Location = New System.Drawing.Point(9, 55)
    Me.ButtonExecuteCommand2.Name = "ButtonExecuteCommand2"
    Me.ButtonExecuteCommand2.Size = New System.Drawing.Size(127, 30)
    Me.ButtonExecuteCommand2.TabIndex = 20
    Me.ButtonExecuteCommand2.Text = "RF field OFF"
    Me.ButtonExecuteCommand2.UseVisualStyleBackColor = True
    '
    'Button2
    '
    Me.Button2.Location = New System.Drawing.Point(573, 397)
    Me.Button2.Name = "Button2"
    Me.Button2.Size = New System.Drawing.Size(75, 24)
    Me.Button2.TabIndex = 15
    Me.Button2.Text = "Button2"
    Me.Button2.UseVisualStyleBackColor = True
    Me.Button2.Visible = False
    '
    'GroupBoxTagnumber
    '
    Me.GroupBoxTagnumber.Controls.Add(Me.GroupBoxIsoNumbers)
    Me.GroupBoxTagnumber.Controls.Add(Me.LabelTagnumber)
    Me.GroupBoxTagnumber.Location = New System.Drawing.Point(12, 12)
    Me.GroupBoxTagnumber.Name = "GroupBoxTagnumber"
    Me.GroupBoxTagnumber.Size = New System.Drawing.Size(480, 129)
    Me.GroupBoxTagnumber.TabIndex = 13
    Me.GroupBoxTagnumber.TabStop = False
    Me.GroupBoxTagnumber.Text = "Tagnumber"
    '
    'GroupBoxIsoNumbers
    '
    Me.GroupBoxIsoNumbers.BackColor = System.Drawing.SystemColors.Control
    Me.GroupBoxIsoNumbers.Controls.Add(Me.Label1)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.CheckBoxDataBlockPresent)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.LabelCountryCode)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.LabelRetaggingCounter)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.Label3)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.Label7)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.LabelID)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.LabelReservedZone)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.Label4)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.Label6)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.LabelTagType)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.LabelUserInformation)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.CheckBoxAnimalTag)
    Me.GroupBoxIsoNumbers.Controls.Add(Me.Label5)
    Me.GroupBoxIsoNumbers.Location = New System.Drawing.Point(7, 48)
    Me.GroupBoxIsoNumbers.Name = "GroupBoxIsoNumbers"
    Me.GroupBoxIsoNumbers.Size = New System.Drawing.Size(468, 56)
    Me.GroupBoxIsoNumbers.TabIndex = 19
    Me.GroupBoxIsoNumbers.TabStop = False
    Me.GroupBoxIsoNumbers.Text = "ISO numbers"
    Me.GroupBoxIsoNumbers.Visible = False
    '
    'Label1
    '
    Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Label1.Location = New System.Drawing.Point(6, 16)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(74, 15)
    Me.Label1.TabIndex = 5
    Me.Label1.Text = "Country Code"
    '
    'CheckBoxDataBlockPresent
    '
    Me.CheckBoxDataBlockPresent.FlatStyle = System.Windows.Forms.FlatStyle.Flat
    Me.CheckBoxDataBlockPresent.Location = New System.Drawing.Point(383, 36)
    Me.CheckBoxDataBlockPresent.Name = "CheckBoxDataBlockPresent"
    Me.CheckBoxDataBlockPresent.RightToLeft = System.Windows.Forms.RightToLeft.Yes
    Me.CheckBoxDataBlockPresent.Size = New System.Drawing.Size(77, 17)
    Me.CheckBoxDataBlockPresent.TabIndex = 18
    Me.CheckBoxDataBlockPresent.Text = "Data Block"
    Me.CheckBoxDataBlockPresent.UseVisualStyleBackColor = True
    '
    'LabelCountryCode
    '
    Me.LabelCountryCode.BackColor = System.Drawing.SystemColors.Window
    Me.LabelCountryCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.LabelCountryCode.Location = New System.Drawing.Point(80, 16)
    Me.LabelCountryCode.Name = "LabelCountryCode"
    Me.LabelCountryCode.Size = New System.Drawing.Size(36, 15)
    Me.LabelCountryCode.TabIndex = 6
    '
    'LabelRetaggingCounter
    '
    Me.LabelRetaggingCounter.BackColor = System.Drawing.SystemColors.Window
    Me.LabelRetaggingCounter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.LabelRetaggingCounter.Location = New System.Drawing.Point(340, 36)
    Me.LabelRetaggingCounter.Name = "LabelRetaggingCounter"
    Me.LabelRetaggingCounter.Size = New System.Drawing.Size(36, 15)
    Me.LabelRetaggingCounter.TabIndex = 17
    '
    'Label3
    '
    Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Label3.Location = New System.Drawing.Point(122, 16)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(24, 15)
    Me.Label3.TabIndex = 7
    Me.Label3.Text = "ID"
    '
    'Label7
    '
    Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Label7.Location = New System.Drawing.Point(238, 36)
    Me.Label7.Name = "Label7"
    Me.Label7.Size = New System.Drawing.Size(101, 15)
    Me.Label7.TabIndex = 16
    Me.Label7.Text = "Retagging Counter"
    '
    'LabelID
    '
    Me.LabelID.BackColor = System.Drawing.SystemColors.Window
    Me.LabelID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.LabelID.Location = New System.Drawing.Point(146, 16)
    Me.LabelID.Name = "LabelID"
    Me.LabelID.Size = New System.Drawing.Size(86, 15)
    Me.LabelID.TabIndex = 8
    '
    'LabelReservedZone
    '
    Me.LabelReservedZone.BackColor = System.Drawing.SystemColors.Window
    Me.LabelReservedZone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.LabelReservedZone.Location = New System.Drawing.Point(210, 36)
    Me.LabelReservedZone.Name = "LabelReservedZone"
    Me.LabelReservedZone.Size = New System.Drawing.Size(22, 15)
    Me.LabelReservedZone.TabIndex = 15
    '
    'Label4
    '
    Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Label4.Location = New System.Drawing.Point(238, 16)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(46, 15)
    Me.Label4.TabIndex = 9
    Me.Label4.Text = "Type"
    '
    'Label6
    '
    Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Label6.Location = New System.Drawing.Point(123, 36)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(87, 15)
    Me.Label6.TabIndex = 14
    Me.Label6.Text = "Reserved Zone"
    '
    'LabelTagType
    '
    Me.LabelTagType.BackColor = System.Drawing.SystemColors.Window
    Me.LabelTagType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.LabelTagType.Location = New System.Drawing.Point(285, 16)
    Me.LabelTagType.Name = "LabelTagType"
    Me.LabelTagType.Size = New System.Drawing.Size(91, 15)
    Me.LabelTagType.TabIndex = 10
    '
    'LabelUserInformation
    '
    Me.LabelUserInformation.BackColor = System.Drawing.SystemColors.Window
    Me.LabelUserInformation.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.LabelUserInformation.Location = New System.Drawing.Point(91, 36)
    Me.LabelUserInformation.Name = "LabelUserInformation"
    Me.LabelUserInformation.Size = New System.Drawing.Size(25, 15)
    Me.LabelUserInformation.TabIndex = 13
    '
    'CheckBoxAnimalTag
    '
    Me.CheckBoxAnimalTag.FlatStyle = System.Windows.Forms.FlatStyle.Flat
    Me.CheckBoxAnimalTag.Location = New System.Drawing.Point(382, 16)
    Me.CheckBoxAnimalTag.Name = "CheckBoxAnimalTag"
    Me.CheckBoxAnimalTag.RightToLeft = System.Windows.Forms.RightToLeft.Yes
    Me.CheckBoxAnimalTag.Size = New System.Drawing.Size(78, 17)
    Me.CheckBoxAnimalTag.TabIndex = 11
    Me.CheckBoxAnimalTag.Text = "Animal Tag"
    Me.CheckBoxAnimalTag.UseVisualStyleBackColor = True
    '
    'Label5
    '
    Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.Label5.Location = New System.Drawing.Point(6, 36)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(87, 15)
    Me.Label5.TabIndex = 12
    Me.Label5.Text = "User Information"
    '
    'StatusStrip1
    '
    Me.StatusStrip1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
    Me.StatusStrip1.Location = New System.Drawing.Point(0, 465)
    Me.StatusStrip1.Name = "StatusStrip1"
    Me.StatusStrip1.Size = New System.Drawing.Size(653, 22)
    Me.StatusStrip1.TabIndex = 16
    Me.StatusStrip1.Text = "StatusStrip1"
    '
    'ToolStripStatusLabel1
    '
    Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
    Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(607, 17)
    Me.ToolStripStatusLabel1.Spring = True
    Me.ToolStripStatusLabel1.Text = "status info goes here..."
    '
    'Form1
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(653, 487)
    Me.Controls.Add(Me.StatusStrip1)
    Me.Controls.Add(Me.Button2)
    Me.Controls.Add(Me.GroupBoxTagnumber)
    Me.Controls.Add(Me.GroupBoxCommands)
    Me.Controls.Add(Me.GroupBoxConnection)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
    Me.MaximizeBox = False
    Me.Name = "Form1"
    Me.Text = "ASR550example_VB"
    Me.GroupBoxConnection.ResumeLayout(False)
    Me.GroupBoxCommands.ResumeLayout(False)
    Me.GroupBoxConfiguration.ResumeLayout(False)
    Me.GroupBoxCfgOutputFormat.ResumeLayout(False)
    Me.GroupBoxCfgDelayTime.ResumeLayout(False)
    Me.GroupBoxCfgSerialBaudrate.ResumeLayout(False)
    Me.GroupBoxDedicatedCommands.ResumeLayout(False)
    Me.GroupBoxGenericCommands.ResumeLayout(False)
    Me.GroupBoxTagnumber.ResumeLayout(False)
    Me.GroupBoxIsoNumbers.ResumeLayout(False)
    Me.StatusStrip1.ResumeLayout(False)
    Me.StatusStrip1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents ComboBoxPorts As System.Windows.Forms.ComboBox
  Friend WithEvents ButtonConnect As System.Windows.Forms.Button
  Friend WithEvents ButtonGetReaderVersion As System.Windows.Forms.Button
  Friend WithEvents LabelTagnumber As System.Windows.Forms.Label
  Friend WithEvents TimerColorNumber As System.Windows.Forms.Timer
  Friend WithEvents ComboBoxBaudrate As System.Windows.Forms.ComboBox
  Friend WithEvents GroupBoxConnection As System.Windows.Forms.GroupBox
  Friend WithEvents LabelBaudrate As System.Windows.Forms.Label
  Friend WithEvents LabelComport As System.Windows.Forms.Label
  Friend WithEvents ButtonGetReaderSerialNumber As System.Windows.Forms.Button
  Friend WithEvents ButtonReset_All As System.Windows.Forms.Button
  Friend WithEvents ButtonStart_FastAutotuning As System.Windows.Forms.Button
  Friend WithEvents ButtonDevice_Check As System.Windows.Forms.Button
  Friend WithEvents GroupBoxCommands As System.Windows.Forms.GroupBox
  Friend WithEvents ButtonGet_AntennaStatus As System.Windows.Forms.Button
  Friend WithEvents ComboBoxCfgDelayTime As System.Windows.Forms.ComboBox
  Friend WithEvents ButtonGetDelaytime As System.Windows.Forms.Button
  Friend WithEvents ButtonSetDelaytime As System.Windows.Forms.Button
  Friend WithEvents ComboBoxCfgOutputFormat As System.Windows.Forms.ComboBox
  Friend WithEvents ButtonSetOutputFormat As System.Windows.Forms.Button
  Friend WithEvents ButtonGetOutputFormat As System.Windows.Forms.Button
  Friend WithEvents GroupBoxCfgOutputFormat As System.Windows.Forms.GroupBox
  Friend WithEvents GroupBoxCfgDelayTime As System.Windows.Forms.GroupBox
  Friend WithEvents GroupBoxTagnumber As System.Windows.Forms.GroupBox
  Friend WithEvents Button2 As System.Windows.Forms.Button
  Friend WithEvents GroupBoxCfgSerialBaudrate As System.Windows.Forms.GroupBox
  Friend WithEvents ButtonSetSerialBaudrate As System.Windows.Forms.Button
  Friend WithEvents ComboBoxCfgSerialBaudrate As System.Windows.Forms.ComboBox
  Friend WithEvents ButtonGetSerialBaudrate As System.Windows.Forms.Button
  Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
  Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents LabelCountryCode As System.Windows.Forms.Label
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents CheckBoxAnimalTag As System.Windows.Forms.CheckBox
  Friend WithEvents LabelTagType As System.Windows.Forms.Label
  Friend WithEvents Label4 As System.Windows.Forms.Label
  Friend WithEvents LabelID As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents LabelReservedZone As System.Windows.Forms.Label
  Friend WithEvents Label6 As System.Windows.Forms.Label
  Friend WithEvents LabelUserInformation As System.Windows.Forms.Label
  Friend WithEvents Label5 As System.Windows.Forms.Label
  Friend WithEvents CheckBoxDataBlockPresent As System.Windows.Forms.CheckBox
  Friend WithEvents LabelRetaggingCounter As System.Windows.Forms.Label
  Friend WithEvents Label7 As System.Windows.Forms.Label
  Friend WithEvents GroupBoxIsoNumbers As System.Windows.Forms.GroupBox
  Friend WithEvents ButtonExecuteCommand1 As System.Windows.Forms.Button
  Friend WithEvents ButtonExecuteCommand2 As System.Windows.Forms.Button
  Friend WithEvents ButtonGetData As System.Windows.Forms.Button
  Friend WithEvents GroupBoxGenericCommands As System.Windows.Forms.GroupBox
  Friend WithEvents GroupBoxConfiguration As System.Windows.Forms.GroupBox
  Friend WithEvents GroupBoxDedicatedCommands As System.Windows.Forms.GroupBox

End Class
